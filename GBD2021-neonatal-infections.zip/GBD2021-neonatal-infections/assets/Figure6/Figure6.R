# Production analysis; paths are relative to this repository.
suppressPackageStartupMessages({
    library(readr)
    library(dplyr)
    library(tidyr)
    library(ggplot2)
    library(countrycode)
    library(patchwork)
})

figure_source_paths <- function() {
    frames <- sys.frames()
    sourced <- unlist(lapply(rev(frames), function(frame) {
        x <- get0("ofile", envir = frame, inherits = FALSE)
        if (is.character(x)) 
            x
        else character()
    }), use.names = FALSE)
    cli <- commandArgs(trailingOnly = FALSE)
    cli <- sub("^--file=", "", cli[grepl("^--file=", cli)])
    cli <- gsub("~+~", " ", cli, fixed = TRUE)
    paths <- c(sourced, cli)
    paths <- paths[!is.na(paths) & nzchar(paths)]
    paths <- paths[file.exists(paths)]
    if (length(paths)) 
        unique(normalizePath(paths, mustWork = TRUE))
    else character()
}

resolve_figure_dir <- function(number, required) {
    stopifnot(length(number) == 1, !is.na(number), number %in% 1:6)
    folder <- paste0("Figure", number)
    paths <- figure_source_paths()
    local_revision_root <- Sys.getenv("GBD_REPO_ROOT", unset = getwd())
    containers <- list.dirs(local_revision_root, recursive = FALSE, full.names = TRUE)
    candidates <- unique(c(dirname(paths), file.path(dirname(dirname(paths)), folder), getwd(), file.path(getwd(), 
        folder), file.path(getwd(), "投稿", "返修", folder), file.path(containers, folder), file.path(local_revision_root, 
        folder)))
    for (candidate in candidates) {
        if (dir.exists(candidate) && basename(candidate) == folder && all(file.exists(file.path(candidate, 
            required)))) {
            return(normalizePath(candidate, mustWork = TRUE))
        }
    }
    stop(paste0("Cannot locate ", folder, " with the required input files. ", "Set the working directory to the correct ", 
        folder, " folder and rerun the complete script. ", "Expected: ", paste(required, collapse = ", ")), 
        call. = FALSE)
}

revision_root <- function(start) {
    p <- normalizePath(start, mustWork = TRUE)
    repeat {
        if (file.exists(file.path(p, "scripts", "project_layout.R"))) 
            return(p)
        parent <- dirname(p)
        if (identical(parent, p)) 
            stop("Cannot locate revision root from ", start)
        p <- parent
    }
}

figure <- 6L

base <- resolve_figure_dir(figure, paste0("Figure", figure, "_raw_neonatal_deaths.csv"))

raw <- base

dataout <- base

figout <- base

prefix <- paste0("Figure", figure)

notes <- file.path(revision_root(base), "scripts", prefix)

dir.create(notes, recursive = TRUE, showWarnings = FALSE)

read_input <- function(x) read_csv(file.path(raw, paste0(prefix, "_raw_", x)), show_col_types = FALSE)

export <- function(x, name) write_csv(x, file.path(dataout, paste0(prefix, "_analysis_", name, ".csv")))

publication_font <- function(p, w, h) {
    if (!is.null(p$labels$title)) 
        p <- p + labs(title = stringr::str_wrap(p$labels$title, width = floor(w * 6)))
    if (!is.null(p$labels$caption)) 
        p <- p + labs(caption = stringr::str_wrap(p$labels$caption, width = floor(w * 7)))
    if (!is.null(p$labels$x) && is.character(p$labels$x)) 
        p <- p + labs(x = stringr::str_wrap(p$labels$x, width = 48))
    if (!is.null(p$labels$y) && is.character(p$labels$y)) 
        p <- p + labs(y = stringr::str_wrap(p$labels$y, width = 48))
    if (is.null(p$labels$title) && exists("figure") && figure == 4) 
        p <- p + labs(title = "High-to-low SDI mortality ratio")
    p <- p + theme(text = element_text(family = "Arial", size = 18), plot.title = element_text(family = "Arial", 
        size = 18, face = "bold", hjust = 0.5, margin = margin(b = 14)), plot.title.position = "plot", 
        plot.subtitle = element_text(family = "Arial", size = 18, hjust = 0.5), axis.text = element_text(family = "Arial", 
            size = 18), axis.title = element_text(family = "Arial", size = 18), axis.text.x = element_text(family = "Arial", 
            size = 18), axis.text.y = element_text(family = "Arial", size = 18), axis.title.x = element_text(family = "Arial", 
            size = 18, margin = margin(t = 12)), axis.title.y = element_text(family = "Arial", size = 18, 
            margin = margin(r = 12)), legend.text = element_text(family = "Arial", size = 18), legend.title = element_blank(), 
        strip.text = element_text(family = "Arial", size = 18), plot.caption = element_text(family = "Arial", 
            size = 18, hjust = 0), plot.margin = margin(24, 32, 24, 28), legend.key.size = grid::unit(0.65, 
            "cm"))
    if (exists("figure") && figure %in% c(2, 4)) 
        p <- p + guides(colour = guide_legend(nrow = 2, byrow = TRUE))
    if (inherits(p$coordinates, "CoordSf")) 
        p <- p + theme(axis.text = element_blank(), axis.text.x = element_blank(), axis.text.y = element_blank(), 
            axis.title = element_blank(), axis.title.x = element_blank(), axis.title.y = element_blank(), 
            legend.title = element_text(family = "Arial", size = 18))
    for (i in seq_along(p$layers)) {
        if (inherits(p$layers[[i]]$geom, "GeomText") || inherits(p$layers[[i]]$geom, "GeomLabel")) {
            p$layers[[i]]$aes_params$family <- "Arial"
            p$layers[[i]]$aes_params$size <- 18/ggplot2::.pt
        }
    }
    p
}

save_plot <- function(p, name, w = 11, h = 8) {
    w <- max(w, 11)
    h <- max(h, 7)
    p <- publication_font(p, w, h)
    ggsave(file.path(figout, paste0(name, ".tif")), p, width = w, height = h, dpi = 600, device = ragg::agg_tiff, 
        compression = "lzw", bg = "white")
}

set.seed(20261101)

theme_set(theme_classic(base_size = 11, base_family = "Arial") + theme(legend.position = "top", plot.title = element_text(face = "bold", 
    size = 12), axis.title = element_text(size = 10), plot.margin = margin(16, 22, 16, 18)))

unit_label <- "Deaths per 1,000 live births"

deaths <- read_input("neonatal_deaths.csv") %>% filter(measure_name == "Deaths", metric_name == "Number", 
    sex_name == "Both", between(year, 1990, 2021))

stopifnot(!anyDuplicated(deaths[c("location_id", "year", "age_name")]))

reference <- read_input("country_reference_rates.csv")

ids <- unique(reference$location_id)

births <- read_input("live_births.csv") %>% filter(measure_name == "Live Births", metric_name == "Number", 
    scenario_name == "Reference", between(year_id, 1990, 2021)) %>% transmute(location_id, year = year_id, 
    births = val, births_lower = lower, births_upper = upper)

stopifnot(!anyDuplicated(births[c("location_id", "year")]))

sdi <- read_input("sdi.csv") %>% filter(sex == "Both", age_group_name == "All Ages", between(year_id, 
    1990, 2021)) %>% transmute(location_id, year = year_id, sdi = mean_value)

stopifnot(!anyDuplicated(sdi[c("location_id", "year")]))

master <- deaths %>% filter(location_id %in% ids) %>% transmute(location_id, location_name, year, age_name, 
    deaths = val, deaths_lower = lower, deaths_upper = upper) %>% left_join(births, by = c("location_id", 
    "year")) %>% left_join(sdi, by = c("location_id", "year")) %>% mutate(rate = deaths/births * 1000)

stopifnot(nrow(master) == 19584, !anyNA(master), all(master$births > 0), all(master$rate > 0))

metadata <- master %>% distinct(location_id, location_name) %>% mutate(iso3 = countrycode(location_name, 
    "country.name", "iso3c", warn = FALSE), continent = countrycode(location_name, "country.name", "continent", 
    warn = FALSE))

stopifnot(!anyNA(metadata))

export(metadata, "country_geography_mapping")

master <- left_join(master, metadata, by = c("location_id", "location_name"))

neo <- filter(master, age_name == "<28 days")

global <- read_input("global_original.csv") %>% filter(measure_name == "Deaths", metric_name == "Number", 
    sex_name == "Both", between(year, 1990, 2021)) %>% transmute(location_id, year, age_name, deaths = val, 
    deaths_lower = lower, deaths_upper = upper) %>% left_join(births, by = c("location_id", "year")) %>% 
    mutate(rate = deaths/births * 1000)

continent <- neo %>% group_by(continent, year) %>% summarise(deaths = sum(deaths), births = sum(births), 
    .groups = "drop") %>% mutate(rate = deaths/births * 1000)

export(master, "country_age_year_master")

export(global, "global_official_ratios")

export(continent, "continent_population_weighted_ratios")

pal_cont <- c(Africa = "#FCC8B1", Americas = "#277D93", Asia = "#E9CE77", Europe = "#789262", Oceania = "#F39402")

pal_age <- c(`0-6 days` = "#3371AE", `7-27 days` = "#E77C8E")

pal_sdi <- c(`Low SDI` = "#00868F", `Low-middle SDI` = "#9C6D57", `Middle SDI` = "#00A68C", `High-middle SDI` = "#7A9EB1", 
    `High SDI` = "#F2E8C9")

{
    curve <- function(d) {
        d <- arrange(d, sdi, location_id)
        d %>% mutate(birth_share = births/sum(births), death_share = deaths/sum(deaths), rank = cumsum(birth_share) - 
            birth_share/2, cum_birth = cumsum(birth_share), cum_death = cumsum(death_share))
    }
    index <- function(d) {
        x <- curve(d)
        2 * sum(x$death_share * x$rank) - 1
    }
    curves <- bind_rows(lapply(c(1990, 2021), function(y) curve(filter(neo, year == y))))
    export(curves, "concentration_curves_endpoints")
    ci <- bind_rows(lapply(1990:2021, function(y) {
        d <- filter(neo, year == y)
        loo <- vapply(seq_len(nrow(d)), function(i) index(d[-i, ]), numeric(1))
        equal <- d %>% mutate(births = 1, deaths = rate)
        tibble(year = y, index_birth_weighted = index(d), index_country_equal_weighted = index(equal), 
            leave_one_out_min = min(loo), leave_one_out_max = max(loo))
    }))
    export(ci, "concentration_indices_and_LOO_sensitivity")
    frontier <- function(d, target) {
        vapply(target, function(s) {
            values <- d$rate[d$sdi <= s]
            if (length(values)) 
                min(values)
            else NA_real_
        }, numeric(1))
    }
    points <- filter(neo, year == 2021) %>% arrange(sdi, location_id)
    points$frontier <- frontier(points, points$sdi)
    points$distance <- points$rate - points$frontier
    points$distance_fraction <- points$distance/points$rate
    loo <- sapply(seq_len(nrow(points)), function(i) frontier(points[-i, ], points$sdi))
    points$LOO_frontier_min <- apply(loo, 1, function(x) if (all(is.na(x))) 
        NA_real_
    else min(x, na.rm = TRUE))
    points$LOO_frontier_max <- apply(loo, 1, function(x) if (all(is.na(x))) 
        NA_real_
    else max(x, na.rm = TRUE))
    export(points, "frontier_country_distances_and_LOO_sensitivity")
    bound <- points %>% filter(!duplicated(frontier))
    export(bound, "empirical_frontier_vertices")
    curve_plot <- bind_rows(curves %>% transmute(year, cum_birth, cum_death), tibble(year = c(1990, 2021), 
        cum_birth = 0, cum_death = 0)) %>% arrange(year, cum_birth)
    p1 <- ggplot(curve_plot, aes(cum_birth, cum_death, color = factor(year))) + geom_line(linewidth = 0.85) + 
        geom_abline(slope = 1, intercept = 0, color = "#656A7D", linetype = 2) + scale_color_manual(values = c(`1990` = "#345F65", 
        `2021` = "#AE4F49")) + labs(x = "Cumulative live-birth share (ranked by SDI)", y = "Cumulative death share", 
        color = NULL, title = "Concentration curves")
    p2 <- ggplot(ci, aes(year, index_birth_weighted)) + geom_line(color = "#14375F", linewidth = 0.85) + 
        labs(x = "Year", y = "Concentration index", title = "Birth-weighted concentration index")
    p3 <- ggplot(points, aes(sdi, rate)) + geom_point(color = "#7BCCC4", size = 1.4) + geom_step(aes(y = frontier), 
        color = "#2E8B57", linewidth = 0.8, direction = "hv") + labs(x = "SDI", y = unit_label, title = "Empirical attainable envelope, 2021")
    save_plot(p1, "Figure6a", 8, 6)
    save_plot(p2, "Figure6b", 8, 5)
    save_plot(p3, "Figure6c", 8, 6)
}

capture.output(sessionInfo(), file = file.path(notes, "sessionInfo.txt"))

interval_renderer <- file.path(revision_root(base), "scripts", "render_interval_figures.R")

if (file.exists(interval_renderer) && Sys.getenv("GBD_STAGE") != "prepare") {
    source(interval_renderer, local = TRUE)
    render_interval_figure(revision_root(base), figure)
}

