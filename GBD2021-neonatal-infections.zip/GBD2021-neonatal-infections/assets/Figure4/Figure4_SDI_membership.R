suppressPackageStartupMessages({library(readxl);library(readr);library(dplyr)})
# Resolve paths for Rscript, source(), or console execution without changing getwd().
figure_source_paths <- function() {
  frames <- sys.frames()
  sourced <- unlist(lapply(rev(frames),function(frame) {
    x <- get0('ofile',envir=frame,inherits=FALSE)
    if(is.character(x)) x else character()
  }),use.names=FALSE)
  cli <- commandArgs(trailingOnly=FALSE)
  cli <- sub('^--file=','',cli[grepl('^--file=',cli)])
  cli <- gsub('~+~',' ',cli,fixed=TRUE)
  paths <- c(sourced,cli)
  paths <- paths[!is.na(paths) & nzchar(paths)]
  paths <- paths[file.exists(paths)]
  if(length(paths)) unique(normalizePath(paths,mustWork=TRUE)) else character()
}
infer_figure_number <- function() {
  paths <- figure_source_paths()
  folders <- c(basename(dirname(paths)),basename(getwd()))
  valid <- folders[grepl('^Figure[1-6]$',folders)]
  if(!length(valid)) stop('Cannot identify Figure number. Run a Figure1.R-Figure6.R script or set the working directory to its Figure folder.',call.=FALSE)
  as.integer(sub('^Figure','',valid[1]))
}
resolve_figure_dir <- function(number,required) {
  stopifnot(length(number)==1,!is.na(number),number %in% 1:6)
  folder <- paste0('Figure',number)
  paths <- figure_source_paths()
  local_revision_root <- Sys.getenv('GBD_REPO_ROOT', unset=getwd())
  containers <- list.dirs(local_revision_root,recursive=FALSE,full.names=TRUE)
  candidates <- unique(c(dirname(paths),file.path(dirname(dirname(paths)),folder),
    getwd(),file.path(getwd(),folder),file.path(getwd(),'投稿','返修',folder),
    file.path(containers,folder),file.path(local_revision_root,folder)))
  for(candidate in candidates) {
    if(dir.exists(candidate) && basename(candidate)==folder &&
       all(file.exists(file.path(candidate,required)))) {
      return(normalizePath(candidate,mustWork=TRUE))
    }
  }
  stop(paste0('Cannot locate ',folder,' with the required input files. ',
    'Set the working directory to the correct ',folder,' folder and rerun the complete script. ',
    'Expected: ',paste(required,collapse=', ')),call.=FALSE)
}
revision_root <- function(start) {
  p <- normalizePath(start,mustWork=TRUE)
  repeat {
    if(file.exists(file.path(p,'scripts','project_layout.R'))) return(p)
    parent <- dirname(p)
    if(identical(parent,p)) stop('Cannot locate revision root from ',start)
    p <- parent
  }
}


figure <- 4L
base <- resolve_figure_dir(figure,'IHME_GBD_SDI_2021_SDI_QUINTILES_Y2024M05D16.XLSX')
qfile <- file.path(base,'IHME_GBD_SDI_2021_SDI_QUINTILES_Y2024M05D16.XLSX')
bfile <- file.path(base,'IHME_GBD_SDI_2021_REF_QUINTILES_Y2024M05D16.XLSX')
q <- read_excel(qfile); names(q) <- c('location_id','location_name','SDI_2021','published_group')
b <- read_excel(bfile)
ids <- unique(read_csv(file.path(base,'Figure4_raw_country_reference_rates.csv'),show_col_types=FALSE)$location_id)
mapping <- q %>% filter(location_id %in% ids)
stopifnot(nrow(mapping)==204,!anyDuplicated(mapping$location_id))
mapping$threshold_group <- as.character(cut(mapping$SDI_2021,
  breaks=c(0,b$upper_bound),labels=b$location_name,include.lowest=TRUE,right=TRUE))
stopifnot(all(is.na(mapping$published_group) | mapping$published_group==mapping$threshold_group))
mapping <- mapping %>% mutate(SDI_group=coalesce(published_group,threshold_group),
  assignment_method=if_else(is.na(published_group),'National 2021 SDI classified using official reference boundaries','Read directly from official quintile workbook'),
  classification_year=2021,
  source_url='https://ghdx.healthdata.org/gbd-2021',
  source_workbook=basename(qfile),reference_boundaries_workbook=basename(bfile))
stopifnot(!anyNA(mapping$SDI_group))
write_csv(mapping,file.path(base,'Figure4_analysis_country_SDI_membership.csv'))
write_csv(b,file.path(base,'Figure4_analysis_official_reference_boundaries.csv'))
write_csv(filter(mapping,is.na(published_group)),file.path(base,'Figure4_analysis_22_national_threshold_assignments.csv'))
cat('204 countries assigned; direct=',sum(!is.na(mapping$published_group)),
    '; threshold-based national assignments=',sum(is.na(mapping$published_group)),'\n')
print(table(mapping$SDI_group))
