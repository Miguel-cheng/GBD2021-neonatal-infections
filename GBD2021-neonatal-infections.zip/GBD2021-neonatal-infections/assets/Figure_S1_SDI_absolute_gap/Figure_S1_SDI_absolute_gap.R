suppressPackageStartupMessages({library(data.table);library(ggplot2)})
# Reproduce the figure from the local analysis CSV; no other script is required.
# Intervals are conditional approximate simulations, not official IHME joint-draw UIs.
folder_name <- 'Figure_S1_SDI_absolute_gap'
data_name <- 'Figure_S1_SDI_absolute_gap_analysis_data.csv'
frames <- sys.frames()
sources <- unlist(lapply(rev(frames),function(f) get0('ofile',envir=f,inherits=FALSE)),use.names=FALSE)
cli <- commandArgs(FALSE)
cli <- gsub('~+~',' ',sub('^--file=','',cli[grepl('^--file=',cli)]),fixed=TRUE)
sources <- c(sources,cli)
sources <- sources[!is.na(sources) & file.exists(sources)]
revision <- Sys.getenv('GBD_REPO_ROOT', unset=getwd())
containers <- list.dirs(revision,recursive=FALSE,full.names=TRUE)
candidates <- unique(c(dirname(sources),getwd(),file.path(getwd(),folder_name),
  file.path(dirname(getwd()),folder_name),file.path(containers,folder_name)))
valid <- candidates[file.exists(file.path(candidates,data_name))]
if(!length(valid)) stop('Cannot locate ',data_name,'. Run this script from its folder.')
base <- normalizePath(valid[1],mustWork=TRUE)
x <- fread(file.path(base,data_name))
stopifnot(all(grepl('Approximate',x$interval_type)))
publication_font <- function(p,w,h) {
  if(!is.null(p$labels$title)) p <- p+labs(title=stringr::str_wrap(p$labels$title,width=floor(w*6)))
  if(!is.null(p$labels$caption)) p <- p+labs(caption=stringr::str_wrap(p$labels$caption,width=floor(w*7)))
  if(!is.null(p$labels$x) && is.character(p$labels$x)) p <- p+labs(x=stringr::str_wrap(p$labels$x,width=48))
  if(!is.null(p$labels$y) && is.character(p$labels$y)) p <- p+labs(y=stringr::str_wrap(p$labels$y,width=48))
  if(is.null(p$labels$title) && exists('figure') && figure==4) p <- p+labs(title='High-to-low SDI mortality ratio')
  p <- p+theme(text=element_text(family='Arial',size=18),
    plot.title=element_text(family='Arial',size=18,face='bold',hjust=.5,margin=margin(b=14)),
    plot.title.position='plot',plot.subtitle=element_text(family='Arial',size=18,hjust=.5),
    axis.text=element_text(family='Arial',size=18),axis.title=element_text(family='Arial',size=18),
    axis.text.x=element_text(family='Arial',size=18),axis.text.y=element_text(family='Arial',size=18),
    axis.title.x=element_text(family='Arial',size=18,margin=margin(t=12)),
    axis.title.y=element_text(family='Arial',size=18,margin=margin(r=12)),
    legend.text=element_text(family='Arial',size=18),legend.title=element_blank(),
    strip.text=element_text(family='Arial',size=18),plot.caption=element_text(family='Arial',size=18,hjust=0),
    plot.margin=margin(24,32,24,28),legend.key.size=grid::unit(.65,'cm'))
  if(exists('figure') && figure %in% c(2,4)) p <- p+guides(
    colour=guide_legend(nrow=1,byrow=TRUE))
  if(inherits(p$coordinates,'CoordSf')) p <- p+theme(
    axis.text=element_blank(),axis.text.x=element_blank(),axis.text.y=element_blank(),
    axis.title=element_blank(),axis.title.x=element_blank(),axis.title.y=element_blank(),
    legend.title=element_text(family='Arial',size=18))
  for(i in seq_along(p$layers)) {
    if(inherits(p$layers[[i]]$geom,'GeomText') || inherits(p$layers[[i]]$geom,'GeomLabel')) {
      p$layers[[i]]$aes_params$family <- 'Arial'
      p$layers[[i]]$aes_params$size <- 18/ggplot2::.pt
    }
  }
  p
}

theme_set(theme_classic(base_size=18,base_family='Arial')+
  theme(legend.position='top',plot.margin=margin(24,32,24,28)))
stopifnot(nrow(x)==32L, identical(sort(x$year),1990:2021))
p <- ggplot(x,aes(year,absolute_gap))+
  geom_ribbon(aes(ymin=absolute_lower_approx,ymax=absolute_upper_approx),fill='#EE7803',alpha=.15)+
  geom_line(color='#EE7803',linewidth=.85)+
  labs(x='Year',y='Absolute gap: Deaths per 1,000 live births',
       title='Absolute gap between low- and high-SDI country groups')
p <- publication_font(p,12,7)+labs(caption=NULL)
ggsave(file.path(base,'Figure_S1_SDI_absolute_gap.tif'),p,width=12,height=7,
  dpi=600,device=ragg::agg_tiff,compression='lzw',bg='white')
message('Completed supplementary Figure S1: ',base)

