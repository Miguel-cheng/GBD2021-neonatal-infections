suppressPackageStartupMessages({
  library(readr); library(dplyr); library(tidyr); library(ggplot2)
  library(countrycode); library(patchwork)
})
# Resolve paths for Rscript, source(), or console execution without changing getwd().
figure_source_paths <- function() {
  frames <- sys.frames()
  sourced <- unlist(lapply(rev(frames),function(frame) {
    x <- get0('ofile',envir=frame,inherits=FALSE)
    if(is.character(x)) x else character()
  }),use.names=FALSE)
  cli <- commandArgs(trailingOnly=FALSE)
  cli <- sub('^--file=','',cli[grepl('^--file=',cli)])
  cli <- gsub('~+~',' ',cli,fixed=TRUE)
  paths <- c(sourced,cli)
  paths <- paths[!is.na(paths) & nzchar(paths)]
  paths <- paths[file.exists(paths)]
  if(length(paths)) unique(normalizePath(paths,mustWork=TRUE)) else character()
}
infer_figure_number <- function() {
  paths <- figure_source_paths()
  folders <- c(basename(dirname(paths)),basename(getwd()))
  valid <- folders[grepl('^Figure[1-6]$',folders)]
  if(!length(valid)) stop('Cannot identify Figure number. Run a Figure1.R-Figure6.R script or set the working directory to its Figure folder.',call.=FALSE)
  as.integer(sub('^Figure','',valid[1]))
}
resolve_figure_dir <- function(number,required) {
  stopifnot(length(number)==1,!is.na(number),number %in% 1:6)
  folder <- paste0('Figure',number)
  paths <- figure_source_paths()
  local_revision_root <- Sys.getenv('GBD_REPO_ROOT', unset=getwd())
  containers <- list.dirs(local_revision_root,recursive=FALSE,full.names=TRUE)
  candidates <- unique(c(dirname(paths),file.path(dirname(dirname(paths)),folder),
    getwd(),file.path(getwd(),folder),file.path(getwd(),'投稿','返修',folder),
    file.path(containers,folder),file.path(local_revision_root,folder)))
  for(candidate in candidates) {
    if(dir.exists(candidate) && basename(candidate)==folder &&
       all(file.exists(file.path(candidate,required)))) {
      return(normalizePath(candidate,mustWork=TRUE))
    }
  }
  stop(paste0('Cannot locate ',folder,' with the required input files. ',
    'Set the working directory to the correct ',folder,' folder and rerun the complete script. ',
    'Expected: ',paste(required,collapse=', ')),call.=FALSE)
}
revision_root <- function(start) {
  p <- normalizePath(start,mustWork=TRUE)
  repeat {
    if(file.exists(file.path(p,'scripts','project_layout.R'))) return(p)
    parent <- dirname(p)
    if(identical(parent,p)) stop('Cannot locate revision root from ',start)
    p <- parent
  }
}


figure <- 2L
base <- resolve_figure_dir(figure,paste0('Figure',figure,'_raw_neonatal_deaths.csv'))
raw <- base; dataout <- base; figout <- base
prefix <- paste0('Figure',figure)
notes <- file.path(revision_root(base),'scripts',prefix)
dir.create(notes,recursive=TRUE,showWarnings=FALSE)
read_input <- function(x) read_csv(file.path(raw,paste0(prefix,'_raw_',x)),show_col_types=FALSE)
export <- function(x,name) write_csv(x,file.path(dataout,paste0(prefix,'_analysis_',name,'.csv')))
publication_font <- function(p,w,h) {
  if(!is.null(p$labels$title)) p <- p+labs(title=stringr::str_wrap(p$labels$title,width=floor(w*6)))
  if(!is.null(p$labels$caption)) p <- p+labs(caption=stringr::str_wrap(p$labels$caption,width=floor(w*7)))
  if(!is.null(p$labels$x) && is.character(p$labels$x)) p <- p+labs(x=stringr::str_wrap(p$labels$x,width=48))
  if(!is.null(p$labels$y) && is.character(p$labels$y)) p <- p+labs(y=stringr::str_wrap(p$labels$y,width=48))
  if(is.null(p$labels$title) && exists('figure') && figure==4) p <- p+labs(title='High-to-low SDI mortality ratio')
  p <- p+theme(text=element_text(family='Arial',size=18),
    plot.title=element_text(family='Arial',size=18,face='bold',hjust=.5,margin=margin(b=14)),
    plot.title.position='plot',plot.subtitle=element_text(family='Arial',size=18,hjust=.5),
    axis.text=element_text(family='Arial',size=18),axis.title=element_text(family='Arial',size=18),
    axis.text.x=element_text(family='Arial',size=18),axis.text.y=element_text(family='Arial',size=18),
    axis.title.x=element_text(family='Arial',size=18,margin=margin(t=12)),
    axis.title.y=element_text(family='Arial',size=18,margin=margin(r=12)),
    legend.text=element_text(family='Arial',size=18),legend.title=element_blank(),
    strip.text=element_text(family='Arial',size=18),plot.caption=element_text(family='Arial',size=18,hjust=0),
    plot.margin=margin(24,32,24,28),legend.key.size=grid::unit(.65,'cm'))
  if(exists('figure') && figure %in% c(2,4)) p <- p+guides(
    colour=guide_legend(nrow=if(figure==2) 1 else 2,byrow=TRUE))
  if(inherits(p$coordinates,'CoordSf')) p <- p+theme(
    axis.text=element_blank(),axis.text.x=element_blank(),axis.text.y=element_blank(),
    axis.title=element_blank(),axis.title.x=element_blank(),axis.title.y=element_blank(),
    legend.title=element_text(family='Arial',size=18))
  for(i in seq_along(p$layers)) {
    if(inherits(p$layers[[i]]$geom,'GeomText') || inherits(p$layers[[i]]$geom,'GeomLabel')) {
      p$layers[[i]]$aes_params$family <- 'Arial'
      p$layers[[i]]$aes_params$size <- 18/ggplot2::.pt
    }
  }
  p
}

save_plot <- function(p,name,w=11,h=8) {
  w <- max(w,11); h <- max(h,7)
  p <- publication_font(p,w,h)
  ggsave(file.path(figout,paste0(name,'.tif')),p,width=w,height=h,dpi=600,
    device=ragg::agg_tiff,compression='lzw',bg='white')
}
set.seed(20261101)
theme_set(theme_classic(base_size=11,base_family='Arial') +
  theme(legend.position='top',plot.title=element_text(face='bold',size=12),
        axis.title=element_text(size=10),plot.margin=margin(16,22,16,18)))
unit_label <- 'Deaths per 1,000 live births'
draft_caption <- 'Point estimates; GBD input uncertainty has not been propagated.'
deaths <- read_input('neonatal_deaths.csv') %>%
  filter(measure_name=='Deaths',metric_name=='Number',sex_name=='Both',between(year,1990,2021))
stopifnot(!anyDuplicated(deaths[c('location_id','year','age_name')]))
reference <- read_input('country_reference_rates.csv')
ids <- unique(reference$location_id)
births <- read_input('live_births.csv') %>%
  filter(measure_name=='Live Births',metric_name=='Number',scenario_name=='Reference',between(year_id,1990,2021)) %>%
  transmute(location_id,year=year_id,births=val,births_lower=lower,births_upper=upper)
stopifnot(!anyDuplicated(births[c('location_id','year')]))
sdi <- read_input('sdi.csv') %>%
  filter(sex=='Both',age_group_name=='All Ages',between(year_id,1990,2021)) %>%
  transmute(location_id,year=year_id,sdi=mean_value)
stopifnot(!anyDuplicated(sdi[c('location_id','year')]))
master <- deaths %>% filter(location_id %in% ids) %>%
  transmute(location_id,location_name,year,age_name,deaths=val,deaths_lower=lower,deaths_upper=upper) %>%
  left_join(births,by=c('location_id','year')) %>% left_join(sdi,by=c('location_id','year')) %>%
  mutate(rate=deaths/births*1000)
stopifnot(nrow(master)==19584,!anyNA(master),all(master$births>0),all(master$rate>0))
metadata <- master %>% distinct(location_id,location_name) %>%
  mutate(iso3=countrycode(location_name,'country.name','iso3c',warn=FALSE),
         continent=countrycode(location_name,'country.name','continent',warn=FALSE))
stopifnot(!anyNA(metadata))
export(metadata,'country_geography_mapping')
master <- left_join(master,metadata,by=c('location_id','location_name'))
neo <- filter(master,age_name=='<28 days')
global <- read_input('global_original.csv') %>%
  filter(measure_name=='Deaths',metric_name=='Number',sex_name=='Both',between(year,1990,2021)) %>%
  transmute(location_id,year,age_name,deaths=val,deaths_lower=lower,deaths_upper=upper) %>%
  left_join(births,by=c('location_id','year')) %>% mutate(rate=deaths/births*1000)
continent <- neo %>% group_by(continent,year) %>%
  summarise(deaths=sum(deaths),births=sum(births),.groups='drop') %>% mutate(rate=deaths/births*1000)
export(master,'country_age_year_master')
export(global,'global_official_ratios')
export(continent,'continent_population_weighted_ratios')
pal_cont <- c(Africa='#FCC8B1',Americas='#277D93',Asia='#E9CE77',Europe='#789262',Oceania='#F39402')
pal_age <- c('0-6 days'='#3371AE','7-27 days'='#E77C8E')
pal_sdi <- c('Low SDI'='#00868F','Low-middle SDI'='#9C6D57','Middle SDI'='#00A68C','High-middle SDI'='#7A9EB1','High SDI'='#F2E8C9')
status <- 'PRELIMINARY: point estimates only; not submission-ready.'

if (figure==1) {
  suppressPackageStartupMessages(library(sf))
  world_file <- file.path(raw,paste0(prefix,'_raw_naturalearth_admin0.rds'))
  if (file.exists(world_file)) world <- readRDS(world_file) else {
    world <- rnaturalearth::ne_countries(scale='medium',returnclass='sf')
    saveRDS(world,world_file)
  }
  # ISO_A3 may contain -99 for France; ISO_A3_EH supplies its actual code.
  world$join_iso <- ifelse(world$iso_a3 %in% c('-99',NA),world$iso_a3_eh,world$iso_a3)
  world$join_iso[world$admin=='France'] <- 'FRA'
  world$join_iso[world$admin=='Norway'] <- 'NOR'
  world$join_iso[world$admin=='Somaliland'] <- 'SOM'
  mapdata <- filter(neo,year==2021)
  export(mapdata,'country_2021')
  export(filter(mapdata,!iso3 %in% world$join_iso),'countries_not_drawn_at_medium_scale')
  world <- filter(world,admin!='Antarctica') %>% left_join(mapdata,by=c('join_iso'='iso3'))
  p1 <- ggplot(world)+geom_sf(aes(fill=rate),color='white',linewidth=.08)+
    scale_fill_gradient(low='#A8C090',high='#4A4B9C',na.value='grey90',name=unit_label)+
    coord_sf(xlim=c(-185,185),ylim=c(-60,90),expand=FALSE,clip='off')+
    theme_void()+theme(legend.position='bottom',plot.margin=margin(18,24,18,24),
      plot.title=element_text(size=12,face='bold',margin=margin(b=12)),
      legend.margin=margin(t=10,r=10,b=0,l=10))+
    labs(title='2021 country mortality')
  ct <- filter(continent,year==2021)
  p2 <- ggplot(ct,aes(reorder(continent,-rate),rate))+geom_col(fill='#76C1C4',width=.65)+
    geom_text(aes(label=sprintf('%.2f',rate)),vjust=-.4,size=3.5)+
    scale_y_continuous(expand=expansion(mult=c(0,.12)))+labs(x=NULL,y=unit_label,title='2021 continent mortality')
  save_plot(p1,'Figure1a',9,5)
  save_plot(p2,'Figure1b',7,5)
}

if (figure==2) {
  p1 <- ggplot(filter(global,age_name=='<28 days'),aes(year,rate))+
    geom_line(color='#023C71',linewidth=.85)+labs(x=NULL,y=unit_label,title='Global mortality, 1990-2021')
  p2 <- ggplot(continent,aes(year,rate,color=continent))+geom_line(linewidth=.85)+
    scale_color_manual(values=pal_cont)+labs(x=NULL,y=unit_label,color=NULL,title='Continent mortality')
  selected <- filter(neo,location_name %in% c('China','Ethiopia','India','Nigeria'))
  # Match the original ggplot discrete palette in its original alphabetical order.
  pal_selected <- c(China='#F8766D',Ethiopia='#7CAE00',India='#00BFC4',Nigeria='#C77CFF')
  export(selected,'selected_country_trends')
  p3 <- ggplot(selected,aes(year,rate,color=location_name))+geom_line(linewidth=.85)+
    scale_color_manual(values=pal_selected)+labs(x='Year',y=unit_label,color=NULL,title='Selected countries')
  save_plot(p1,'Figure2a',8,5)
  save_plot(p2,'Figure2b',8,5)
  save_plot(p3,'Figure2c',8,5)
}

if (figure==3) {
  stop('No submission-ready Figure3: exploratory forecasts were withdrawn after inadequate holdout coverage. Decide whether to remove forecasting or rebuild and validate it before generating Figure3.tif.')
  suppressPackageStartupMessages(library(forecast))
  # These model-only intervals condition on the GBD mean series, not input draws.
  predict_series <- function(rate,method,h) {
    z <- ts(log(rate),frequency=1)
    fc <- switch(method,naive=naive(z,h=h,level=95),drift=rwf(z,h=h,drift=TRUE,level=95),
      damped=forecast(ets(z,model='AAN',damped=TRUE),h=h,level=95))
    tibble(estimate=exp(as.numeric(fc$mean)),lower_model_only=exp(as.numeric(fc$lower[,1])),
           upper_model_only=exp(as.numeric(fc$upper[,1])))
  }
  validation <- list(); future <- list(); sensitivity <- list()
  for (age in c('<28 days','0-6 days','7-27 days')) {
    series <- filter(global,age_name==age) %>% arrange(year)
    for (cut in c(2011,2016)) for (method in c('naive','drift','damped')) {
      train <- filter(series,year<=cut); test <- filter(series,year>cut)
      pred <- predict_series(train$rate,method,nrow(test))
      validation[[length(validation)+1]] <- bind_cols(test %>% select(year,rate),pred) %>%
        mutate(age_name=age,train_end=cut,method=method,absolute_error=abs(rate-estimate),
               squared_error=(rate-estimate)^2,covered=rate>=lower_model_only & rate<=upper_model_only)
    }
  }
  vd <- bind_rows(validation)
  score <- vd %>% group_by(age_name,method) %>% summarise(MAE=mean(absolute_error),RMSE=sqrt(mean(squared_error)),
    model_only_coverage=mean(covered),.groups='drop')
  chosen <- score %>% group_by(age_name) %>% slice_min(MAE,n=1,with_ties=FALSE) %>% ungroup()
  for (age in chosen$age_name) {
    series <- filter(global,age_name==age) %>% arrange(year)
    method <- chosen$method[chosen$age_name==age]
    future[[age]] <- predict_series(series$rate,method,9) %>% mutate(year=2022:2030,age_name=age,method=method)
    for (end in c(2019,2021)) for (start in c(1990,2000,2010)) {
      ss <- filter(series,year>=start,year<=end)
      sensitivity[[length(sensitivity)+1]] <- predict_series(ss$rate,method,2030-end) %>%
        mutate(year=(end+1):2030,age_name=age,train_start=start,train_end=end,method=method)
    }
  }
  fc <- bind_rows(future); sens <- bind_rows(sensitivity)
  export(vd,'temporal_holdout_predictions');export(score,'temporal_holdout_scores')
  export(chosen,'selected_models');export(fc,'forecast_2022_2030_model_only')
  export(sens,'training_window_and_preCOVID_sensitivity')
  p1 <- ggplot()+geom_line(data=filter(global,age_name=='<28 days'),aes(year,rate),color='#EE7803',linewidth=.85)+
    geom_ribbon(data=filter(fc,age_name=='<28 days'),aes(year,ymin=lower_model_only,ymax=upper_model_only),fill='#153C46',alpha=.25)+
    geom_line(data=filter(fc,age_name=='<28 days'),aes(year,estimate),color='#EE7803',linetype=2,linewidth=.85)+
    labs(x=NULL,y=unit_label,title='Exploratory global forecast')
  p2 <- ggplot()+geom_line(data=filter(global,age_name!='<28 days'),aes(year,rate,color=age_name),linewidth=.85)+
    geom_line(data=filter(fc,age_name!='<28 days'),aes(year,estimate,color=age_name),linetype=2,linewidth=.85)+
    scale_color_manual(values=pal_age)+labs(x='Year',y=unit_label,color=NULL,title='Early and late neonatal forecasts')
  change <- filter(fc,year==2030,age_name!='<28 days') %>%
    left_join(filter(global,year==2021) %>% select(age_name,baseline=rate),by='age_name') %>% mutate(change_percent=(estimate/baseline-1)*100)
  export(change,'projected_change_point_only')
  p3 <- ggplot(change,aes(age_name,change_percent,fill=age_name))+geom_col(width=.6)+
    scale_fill_manual(values=pal_age)+guides(fill='none')+geom_hline(yintercept=0,linetype=2)+
    labs(x=NULL,y='Change from 2021 (%)',title='2030 projected change (point estimate)')
  # Figure3 export is intentionally disabled until its validation is adequate.
  status <- 'EXPLORATORY ONLY: simple models backtested; full GBD uncertainty propagation and external forecast comparison pending. APC not retained.'
}

if (figure==4) {
  groups <- deaths %>% filter(!location_id %in% ids,age_name=='<28 days')
  export(groups,'official_SDI_neonatal_counts')
  mapping_file <- file.path(raw,paste0(prefix,'_raw_verified_GBD2021_SDI_membership.csv'))
  if (!file.exists(mapping_file)) {
    writeLines(c('location_id,SDI_group,source_url,classification_year'),file.path(notes,'REQUIRED_verified_SDI_mapping_template.csv'))
    status <- paste('BLOCKED: verified GBD2021 country-to-SDI-group membership is missing.',
      'Do not infer groups from arbitrary thresholds or annual quintiles.',
      'No birth-denominator Figure4 has been produced.')
  } else {
    mapping <- read_csv(mapping_file,show_col_types=FALSE)
    stopifnot(nrow(mapping)==204,!anyDuplicated(mapping$location_id),setequal(mapping$location_id,ids),
      all(mapping$SDI_group %in% names(pal_sdi)),all(nzchar(mapping$source_url)))
    grouped <- neo %>% left_join(mapping,by='location_id') %>% group_by(SDI_group,year) %>%
      summarise(deaths=sum(deaths),births=sum(births),.groups='drop') %>% mutate(rate=deaths/births*1000)
    export(grouped,'SDI_group_ratios')
    gap <- grouped %>% select(SDI_group,year,rate) %>% pivot_wider(names_from=SDI_group,values_from=rate) %>%
      mutate(absolute_gap=`Low SDI`-`High SDI`,low_high_ratio=`Low SDI`/`High SDI`)
    export(gap,'SDI_absolute_relative_gaps')
    p1 <- ggplot(grouped,aes(year,rate,color=SDI_group))+geom_line()+scale_color_manual(values=pal_sdi)+labs(x=NULL,y=unit_label,color=NULL)
    p2 <- ggplot(filter(grouped,year==2021),aes(SDI_group,rate,fill=SDI_group))+geom_col()+scale_fill_manual(values=pal_sdi)+guides(fill='none')+labs(x=NULL,y=unit_label)
    p3 <- ggplot(gap,aes(year,low_high_ratio))+geom_line(color='#EE7803')+labs(x='Year',y='Low / high SDI rate ratio')
    save_plot(p1,'Figure4a',8,5)
    save_plot(p2,'Figure4b',8,5)
    save_plot(p3,'Figure4c',8,5)
  }
}

if (figure==5) {
  endpoints <- neo %>% filter(year %in% c(1990,2021)) %>% select(location_id,location_name,year,rate) %>%
    pivot_wider(names_from=year,values_from=rate,names_prefix='rate_') %>%
    mutate(reduction_percent=(1-rate_2021/rate_1990)*100) %>% arrange(desc(rate_2021)) %>% mutate(rank_2021=row_number())
  export(endpoints,'all_country_rankings_and_changes')
  top10 <- slice_head(endpoints,n=10)
  slow <- endpoints %>% slice_head(n=30) %>% arrange(reduction_percent) %>% slice_head(n=10)
  export(top10,'top10_2021_point');export(slow,'slowest10_within_top30_2021')
  sensitivity <- bind_rows(lapply(c(20,30,40,50),function(n) endpoints %>% slice_head(n=n) %>%
    arrange(reduction_percent) %>% slice_head(n=10) %>% mutate(selection_top_n=n,selection_basis='2021 rate')))
  export(sensitivity,'country_cutoff_sensitivity')
  export(endpoints %>% arrange(desc(rate_1990)) %>% slice_head(n=30) %>% arrange(reduction_percent),'baseline1990_top30_selection_sensitivity')
  p1 <- ggplot(top10,aes(rate_2021,reorder(location_name,rate_2021)))+geom_col(fill='#f8c387',width=.65)+
    labs(x=unit_label,y=NULL,title='Ten highest country point estimates, 2021')
  p2 <- ggplot(slow,aes(reduction_percent,reorder(location_name,-reduction_percent)))+geom_col(fill='#f8c387',width=.65)+
    labs(x='Reduction from 1990 to 2021 (%)',y=NULL,title='Smallest reductions among the 30 highest in 2021')
  save_plot(p1,'Figure5a',10,6)
  save_plot(p2,'Figure5b',10,6)
}

if (figure==6) {
  curve <- function(d) {
    d <- arrange(d,sdi,location_id)
    d %>% mutate(birth_share=births/sum(births),death_share=deaths/sum(deaths),
      rank=cumsum(birth_share)-birth_share/2,cum_birth=cumsum(birth_share),cum_death=cumsum(death_share))
  }
  index <- function(d) { x<-curve(d); 2*sum(x$death_share*x$rank)-1 }
  curves <- bind_rows(lapply(c(1990,2021),function(y) curve(filter(neo,year==y))))
  export(curves,'concentration_curves_endpoints')
  ci <- bind_rows(lapply(1990:2021,function(y) {
    d<-filter(neo,year==y)
    loo<-vapply(seq_len(nrow(d)),function(i) index(d[-i,]),numeric(1))
    equal <- d %>% mutate(births=1,deaths=rate)
    tibble(year=y,index_birth_weighted=index(d),index_country_equal_weighted=index(equal),
      leave_one_out_min=min(loo),leave_one_out_max=max(loo))
  }))
  export(ci,'concentration_indices_and_LOO_sensitivity')
  # Empirical attainable envelope: minimum among countries at equal/lower SDI.
  frontier <- function(d,target) {
    vapply(target,function(s) { values<-d$rate[d$sdi<=s]; if(length(values)) min(values) else NA_real_ },numeric(1))
  }
  points <- filter(neo,year==2021) %>% arrange(sdi,location_id)
  points$frontier <- frontier(points,points$sdi)
  points$distance <- points$rate-points$frontier
  points$distance_fraction <- points$distance/points$rate
  loo <- sapply(seq_len(nrow(points)),function(i) frontier(points[-i,],points$sdi))
  points$LOO_frontier_min <- apply(loo,1,function(x) if(all(is.na(x))) NA_real_ else min(x,na.rm=TRUE))
  points$LOO_frontier_max <- apply(loo,1,function(x) if(all(is.na(x))) NA_real_ else max(x,na.rm=TRUE))
  export(points,'frontier_country_distances_and_LOO_sensitivity')
  bound <- points %>% filter(!duplicated(frontier))
  export(bound,'empirical_frontier_vertices')
  curve_plot <- bind_rows(curves %>% transmute(year,cum_birth,cum_death),tibble(year=c(1990,2021),cum_birth=0,cum_death=0)) %>% arrange(year,cum_birth)
  p1 <- ggplot(curve_plot,aes(cum_birth,cum_death,color=factor(year)))+geom_line(linewidth=.85)+
    geom_abline(slope=1,intercept=0,color='#656A7D',linetype=2)+
    scale_color_manual(values=c('1990'='#345F65','2021'='#AE4F49'))+
    labs(x='Cumulative live-birth share (ranked by SDI)',y='Cumulative death share',color=NULL,title='Concentration curves')
  p2 <- ggplot(ci,aes(year,index_birth_weighted))+geom_line(color='#14375F',linewidth=.85)+
    labs(x='Year',y='Concentration index',title='Birth-weighted concentration index')
  p3 <- ggplot(points,aes(sdi,rate))+geom_point(color='#7BCCC4',size=1.4)+
    geom_step(aes(y=frontier),color='#2E8B57',linewidth=.8,direction='hv')+
    labs(x='SDI',y=unit_label,title='Empirical attainable envelope, 2021')
  save_plot(p1,'Figure6a',8,6)
  save_plot(p2,'Figure6b',8,5)
  save_plot(p3,'Figure6c',8,6)
}

writeLines(status,file.path(notes,'STATUS.txt'))
capture.output(sessionInfo(),file=file.path(notes,'sessionInfo.txt'))
writeLines(c(paste('Figure',figure),status,
  'Source death and birth marginal intervals are retained in analysis tables; no derived GBD UI is claimed.',
  'All new files are separate from original data and manuscript.',
  'Continent geography: countrycode continent classification; Americas combines North and South America.',
  'Rate = cause-specific neonatal death-count mean / same-year live-birth mean * 1000.',
  'Source SDI is continuous; SDI quintile mapping must be independently verified.',
  paste0('Reproduce with: Rscript ',prefix,'.R (or an absolute script path).')),file.path(notes,'METHODS_AND_LIMITATIONS.txt'))
message('Completed Figure ',figure,': ',status)

# Reapply the audited interval layer after the original point-estimate plots.
interval_renderer <- file.path(revision_root(base),'scripts','render_interval_figures.R')
if (file.exists(interval_renderer) && Sys.getenv('GBD_STAGE') != 'prepare') {
  source(interval_renderer,local=TRUE)
  render_interval_figure(revision_root(base),figure)
}
