suppressPackageStartupMessages({library(readr);library(dplyr);library(tidyr);library(forecast);library(ggplot2)})
# Resolve paths for Rscript, source(), or console execution without changing getwd().
figure_source_paths <- function() {
  frames <- sys.frames()
  sourced <- unlist(lapply(rev(frames),function(frame) {
    x <- get0('ofile',envir=frame,inherits=FALSE)
    if(is.character(x)) x else character()
  }),use.names=FALSE)
  cli <- commandArgs(trailingOnly=FALSE)
  cli <- sub('^--file=','',cli[grepl('^--file=',cli)])
  cli <- gsub('~+~',' ',cli,fixed=TRUE)
  paths <- c(sourced,cli)
  paths <- paths[!is.na(paths) & nzchar(paths)]
  paths <- paths[file.exists(paths)]
  if(length(paths)) unique(normalizePath(paths,mustWork=TRUE)) else character()
}
infer_figure_number <- function() {
  paths <- figure_source_paths()
  folders <- c(basename(dirname(paths)),basename(getwd()))
  valid <- folders[grepl('^Figure[1-6]$',folders)]
  if(!length(valid)) stop('Cannot identify Figure number. Run a Figure1.R-Figure6.R script or set the working directory to its Figure folder.',call.=FALSE)
  as.integer(sub('^Figure','',valid[1]))
}
resolve_figure_dir <- function(number,required) {
  stopifnot(length(number)==1,!is.na(number),number %in% 1:6)
  folder <- paste0('Figure',number)
  paths <- figure_source_paths()
  local_revision_root <- Sys.getenv('GBD_REPO_ROOT', unset=getwd())
  containers <- list.dirs(local_revision_root,recursive=FALSE,full.names=TRUE)
  candidates <- unique(c(dirname(paths),file.path(dirname(dirname(paths)),folder),
    getwd(),file.path(getwd(),folder),file.path(getwd(),'投稿','返修',folder),
    file.path(containers,folder),file.path(local_revision_root,folder)))
  for(candidate in candidates) {
    if(dir.exists(candidate) && basename(candidate)==folder &&
       all(file.exists(file.path(candidate,required)))) {
      return(normalizePath(candidate,mustWork=TRUE))
    }
  }
  stop(paste0('Cannot locate ',folder,' with the required input files. ',
    'Set the working directory to the correct ',folder,' folder and rerun the complete script. ',
    'Expected: ',paste(required,collapse=', ')),call.=FALSE)
}
revision_root <- function(start) {
  p <- normalizePath(start,mustWork=TRUE)
  repeat {
    if(file.exists(file.path(p,'scripts','project_layout.R'))) return(p)
    parent <- dirname(p)
    if(identical(parent,p)) stop('Cannot locate revision root from ',start)
    p <- parent
  }
}


figure <- 3L
base <- resolve_figure_dir(figure,paste0('Figure',figure,'_raw_global_original.csv'))
notes <- file.path(revision_root(base),'scripts','Figure3')
dir.create(notes,recursive=TRUE,showWarnings=FALSE)
out <- function(x,n) write_csv(x,file.path(base,paste0('Figure3_analysis_',n,'.csv')))
publication_font <- function(p,w,h) {
  if(!is.null(p$labels$title)) p <- p+labs(title=stringr::str_wrap(p$labels$title,width=floor(w*6)))
  if(!is.null(p$labels$caption)) p <- p+labs(caption=stringr::str_wrap(p$labels$caption,width=floor(w*7)))
  if(!is.null(p$labels$x) && is.character(p$labels$x)) p <- p+labs(x=gsub('[\r\n]+',' ',p$labels$x))
  if(!is.null(p$labels$y) && is.character(p$labels$y)) p <- p+labs(y=stringr::str_wrap(p$labels$y,width=48))
  if(is.null(p$labels$title) && exists('figure') && figure==4) p <- p+labs(title='High-to-low SDI mortality ratio')
  p <- p+theme(text=element_text(family='Arial',size=18),
    plot.title=element_text(family='Arial',size=18,face='bold',hjust=.5,margin=margin(b=14)),
    plot.title.position='plot',plot.subtitle=element_text(family='Arial',size=18,hjust=.5),
    axis.text=element_text(family='Arial',size=18),axis.title=element_text(family='Arial',size=18),
    axis.text.x=element_text(family='Arial',size=18),axis.text.y=element_text(family='Arial',size=18),
    axis.title.x=element_text(family='Arial',size=18,margin=margin(t=12)),
    axis.title.y=element_text(family='Arial',size=18,margin=margin(r=12)),
    legend.text=element_text(family='Arial',size=18),legend.title=element_blank(),
    strip.text=element_text(family='Arial',size=18),plot.caption=element_text(family='Arial',size=18,hjust=0),
    plot.margin=margin(24,32,24,28),legend.key.size=grid::unit(.65,'cm'))
  if(exists('figure') && figure %in% c(2,4)) p <- p+guides(
    colour=guide_legend(nrow=2,byrow=TRUE))
  if(inherits(p$coordinates,'CoordSf')) p <- p+theme(
    axis.text=element_blank(),axis.text.x=element_blank(),axis.text.y=element_blank(),
    axis.title=element_blank(),axis.title.x=element_blank(),axis.title.y=element_blank(),
    legend.title=element_text(family='Arial',size=18))
  for(i in seq_along(p$layers)) {
    if(inherits(p$layers[[i]]$geom,'GeomText') || inherits(p$layers[[i]]$geom,'GeomLabel')) {
      p$layers[[i]]$aes_params$family <- 'Arial'
      p$layers[[i]]$aes_params$size <- 18/ggplot2::.pt
    }
  }
  p
}

save_plot <- function(p,n,w=8,h=5) {
  w <- max(w,12); h <- max(h,7.5)
  p <- publication_font(p,w,h)
  ggsave(file.path(base,paste0(n,'.tif')),p,width=w,height=h,dpi=600,
    device=ragg::agg_tiff,compression='lzw',bg='white')
}
set.seed(20261101)
theme_set(theme_classic(base_size=11,base_family='Arial')+
  theme(plot.margin=margin(16,24,16,18),plot.title=element_text(face='bold',size=12),
    legend.position='top',legend.title=element_blank(),plot.caption=element_text(size=8)))
deaths <- read_csv(file.path(base,'Figure3_raw_global_original.csv'),show_col_types=FALSE) %>%
  filter(measure_name=='Deaths',metric_name=='Number',sex_name=='Both',between(year,1990,2021))
births <- read_csv(file.path(base,'Figure3_raw_live_births.csv'),show_col_types=FALSE) %>%
  filter(location_id==1,measure_name=='Live Births',metric_name=='Number',scenario_name=='Reference',between(year_id,1990,2021)) %>%
  transmute(year=year_id,births=val,births_lower=lower,births_upper=upper)
stopifnot(!anyDuplicated(births$year))
d <- deaths %>% select(year,age_name,deaths=val,deaths_lower=lower,deaths_upper=upper) %>%
  left_join(births,by='year') %>% mutate(rate=1000*deaths/births) %>% arrange(age_name,year)
stopifnot(nrow(d)==96,!anyNA(d))
check <- d %>% select(year,age_name,deaths) %>% pivot_wider(names_from=age_name,values_from=deaths)
stopifnot(max(abs(check$`0-6 days`+check$`7-27 days`-check$`<28 days`))<1e-6)
s <- filter(d,age_name=='<28 days') %>% arrange(year)
out(d,'verified_historical_inputs')
methods <- c('naive','drift','damped_ETS','local_linear_trend','ARIMA011')
cache <- new.env(parent=emptyenv())
parameters <- function(log_y,method,h) {
  z <- ts(log_y,frequency=1)
  fit <- switch(method,naive=NULL,drift=NULL,
    damped_ETS=ets(z,model='AAN',damped=TRUE),
    local_linear_trend=StructTS(z,type='trend'),
    ARIMA011=Arima(z,order=c(0,1,1),include.drift=TRUE))
  fc <- switch(method,naive=naive(z,h=h,level=95),drift=rwf(z,h=h,drift=TRUE,level=95),
    forecast(fit,h=h,level=95))
  mu <- as.numeric(fc$mean)
  sigma <- (as.numeric(fc$upper[,1])-as.numeric(fc$lower[,1]))/(2*qnorm(.975))
  list(mu=mu,sigma=sigma,point=exp(mu+sigma^2/2),
    lower=exp(mu-qnorm(.975)*sigma),upper=exp(mu+qnorm(.975)*sigma),fit=fit,fc=fc)
}
cached_prediction <- function(origin,method,h) {
  key <- paste(origin,method,h,sep='_')
  if(!exists(key,envir=cache,inherits=FALSE)) {
    assign(key,parameters(log(s$rate[s$year<=origin]),method,h),envir=cache)
  }
  get(key,envir=cache,inherits=FALSE)
}
# Nested selection uses no outcome after its outer origin. All analyses are retrospective.
select_method <- function(end) {
  rows <- list()
  for(origin in 2002:(end-1)) {
    h <- min(5,end-origin)
    actual <- s$rate[match((origin+1):(origin+h),s$year)]
    for(method in methods) {
      p <- cached_prediction(origin,method,h)
      rows[[length(rows)+1]] <- tibble(method=method,origin=origin,horizon=1:h,
        absolute_error=abs(p$point-actual),squared_error=(p$point-actual)^2)
    }
  }
  scores <- bind_rows(rows) %>% group_by(method) %>%
    summarise(MAE=mean(absolute_error),RMSE=sqrt(mean(squared_error)),.groups='drop') %>% arrange(MAE,method)
  list(method=scores$method[1],scores=scores)
}
validation <- list(); selections <- list()
for(origin in 2005:2012) {
  h <- 9
  years <- (origin+1):(origin+h)
  actual <- s$rate[match(years,s$year)]
  selected <- select_method(origin)
  selections[[length(selections)+1]] <- tibble(origin=origin,selected_method=selected$method,training_last_year=origin)
  for(method in methods) {
    p <- cached_prediction(origin,method,h)
    v <- tibble(origin=origin,year=years,horizon=1:h,method=method,actual=actual,
      estimate=p$point,lower_model_only=p$lower,upper_model_only=p$upper,training_last_year=origin)
    validation[[length(validation)+1]] <- v
    if(method==selected$method) validation[[length(validation)+1]] <- mutate(v,method='nested_selection')
  }
}
v <- bind_rows(validation) %>% mutate(error=estimate-actual,
  covered=actual>=lower_model_only & actual<=upper_model_only,
  interval_score=(upper_model_only-lower_model_only)+40*pmax(lower_model_only-actual,0)+40*pmax(actual-upper_model_only,0))
scores <- v %>% group_by(method) %>% summarise(MAE=mean(abs(error)),RMSE=sqrt(mean(error^2)),
  model_only_coverage=mean(covered),mean_interval_score=mean(interval_score),n=n(),.groups='drop')
out(v,'total_rolling_origin_predictions');out(scores,'total_validation_scores')
out(bind_rows(selections),'nested_model_selections')
out(v %>% group_by(method,horizon) %>% summarise(MAE=mean(abs(error)),coverage=mean(covered),.groups='drop'),'validation_by_horizon')
final <- select_method(2021); chosen <- final$method
out(final$scores,'final_model_selection_scores')
f <- parameters(log(s$rate),chosen,9)
conditional <- tibble(year=2022:2030,estimate=f$point,lower_model_only=f$lower,upper_model_only=f$upper,method=chosen)
out(conditional,'conditional_forecast')
diagnostics <- tibble(method=chosen,n=32)
if(!is.null(f$fit)) {
  res <- as.numeric(residuals(f$fit)); res <- res[is.finite(res)]
  diagnostics$Ljung_Box_lag5_p <- Box.test(res,lag=5,type='Ljung-Box',fitdf=0)$p.value
}
out(diagnostics,'residual_diagnostics')

# Moment-matched marginal lognormals are an approximation, not recovered IHME draws.
s <- s %>% mutate(death_log_sd=(log(deaths_upper)-log(deaths_lower))/(2*qnorm(.975)),
  birth_log_sd=(log(births_upper)-log(births_lower))/(2*qnorm(.975)))
out(s %>% transmute(year,source_lower=deaths_lower,source_upper=deaths_upper,
  fitted_lower=exp(log(deaths)-death_log_sd^2/2-qnorm(.975)*death_log_sd),
  fitted_upper=exp(log(deaths)-death_log_sd^2/2+qnorm(.975)*death_log_sd)),
  'lognormal_marginal_fit_check')
ar_normals <- function(n,rho) {
  z <- rnorm(n)
  if(n>1) for(i in 2:n) z[i] <- rho*z[i-1]+sqrt(1-rho^2)*z[i]
  z
}
simulate_input <- function(rho_time,rho_death_birth,n_sim) {
  set.seed(20261101)
  future <- matrix(NA_real_,n_sim,9); history <- matrix(NA_real_,n_sim,nrow(s))
  failures <- 0L; warnings <- 0L
  for(i in seq_len(n_sim)) {
    zd <- ar_normals(nrow(s),rho_time)
    zb <- rho_death_birth*zd+sqrt(1-rho_death_birth^2)*ar_normals(nrow(s),rho_time)
    log_rate <- log(s$deaths)-s$death_log_sd^2/2+s$death_log_sd*zd-
      (log(s$births)-s$birth_log_sd^2/2+s$birth_log_sd*zb)+log(1000)
    history[i,] <- exp(log_rate)
    p <- tryCatch(withCallingHandlers(parameters(log_rate,chosen,9),warning=function(w){
      warnings <<- warnings+1L; invokeRestart('muffleWarning')
    }),error=function(e)NULL)
    if(is.null(p)) {failures <- failures+1L;next}
    # Pointwise predictive marginals; no joint future-path functional is reported.
    future[i,] <- exp(p$mu+p$sigma*rnorm(9))
  }
  ok <- complete.cases(future)
  if(mean(ok)<.95) stop('More than 5% simulation fits failed; inspect the model.')
  summary <- tibble(year=2022:2030,simulation_mean=colMeans(future[ok,,drop=FALSE]),
    lower_approx=apply(future[ok,,drop=FALSE],2,quantile,.025),
    upper_approx=apply(future[ok,,drop=FALSE],2,quantile,.975),rho_time=rho_time,
    rho_death_birth=rho_death_birth,n_success=sum(ok),n_failure=failures,n_warning=warnings)
  list(summary=summary,history=history,future=future,ok=ok)
}
scenarios <- tibble(rho_time=c(.9,0,.5,.99,.9,.9),rho_death_birth=c(0,0,0,0,-.5,.5),
  scenario=c('central_assumptions','time_independent','time_0.5','time_0.99','death_birth_minus0.5','death_birth_plus0.5'))
sensitivity <- list()
for(i in seq_len(nrow(scenarios))) {
  n_sim <- if(i==1) 2000 else 600
  sim <- simulate_input(scenarios$rho_time[i],scenarios$rho_death_birth[i],n_sim)
  sensitivity[[i]] <- sim$summary %>% mutate(scenario=scenarios$scenario[i])
  if(i==1) central <- sim
  message('Completed uncertainty scenario: ',scenarios$scenario[i])
}
out(bind_rows(sensitivity),'input_dependence_sensitivity')
draw_table <- as_tibble(central$future[central$ok,,drop=FALSE],.name_repair='minimal')
names(draw_table) <- paste0('rate_',2022:2030)
draw_table <- bind_cols(tibble(simulation_id=which(central$ok),
  baseline_rate_2021=central$history[central$ok,nrow(s)]),draw_table)
out(draw_table,'approximate_simulation_draws_NOT_IHME_draws')
historical_draw_table <- as_tibble(central$history,.name_repair='minimal')
names(historical_draw_table) <- paste0('rate_',s$year)
historical_draw_table <- bind_cols(tibble(simulation_id=seq_len(nrow(central$history))),historical_draw_table)
out(historical_draw_table,'approximate_historical_draws_NOT_IHME_draws')
forecast_table <- central$summary %>% mutate(point_forecast=f$point,method=chosen,
  interval_type='95% approximate model-plus-input simulation; not official GBD UI')
out(forecast_table,'total_forecast_with_approximate_intervals')
history <- tibble(year=s$year,point_rate=s$rate,
  lower_approx=apply(central$history,2,quantile,.025),upper_approx=apply(central$history,2,quantile,.975))
out(history,'historical_rate_approximate_intervals')
change_draws <- (central$future[central$ok,9]/central$history[central$ok,nrow(s)]-1)*100
endpoint <- tibble(year=2030,method=chosen,rate_point=f$point[9],rate_lower_approx=forecast_table$lower_approx[9],
  rate_upper_approx=forecast_table$upper_approx[9],change_percent_point=(f$point[9]/tail(s$rate,1)-1)*100,
  change_lower_approx=unname(quantile(change_draws,.025)),change_upper_approx=unname(quantile(change_draws,.975)))
out(endpoint,'2030_endpoint')
windows <- list()
for(start in c(1990,2000,2010)) for(end in c(2019,2021)) {
  x <- filter(s,year>=start,year<=end)
  ff <- parameters(log(x$rate),chosen,2030-end)
  windows[[length(windows)+1]] <- tibble(train_start=start,train_end=end,year=(end+1):2030,
    point=ff$point,lower_model_only=ff$lower,upper_model_only=ff$upper)
}
out(bind_rows(windows),'window_and_preCOVID_sensitivity')
composition <- d %>% filter(age_name!='<28 days') %>%
  left_join(d %>% filter(age_name=='<28 days') %>% select(year,total_deaths=deaths),by='year') %>%
  mutate(share=deaths/total_deaths)
stopifnot(all(abs((composition %>% group_by(year) %>% summarise(t=sum(share)))$t-1)<1e-10))
out(composition,'historical_age_composition')

anchor <- tibble(year=2021,point_forecast=tail(s$rate,1),lower_approx=tail(history$lower_approx,1),upper_approx=tail(history$upper_approx,1))
future_plot <- bind_rows(anchor,select(forecast_table,year,point_forecast,lower_approx,upper_approx))
p1 <- ggplot()+geom_ribbon(data=history,aes(year,ymin=lower_approx,ymax=upper_approx),fill='#153C46',alpha=.12)+
  geom_line(data=history,aes(year,point_rate),color='#EE7803',linewidth=.9)+
  geom_ribbon(data=future_plot,aes(year,ymin=lower_approx,ymax=upper_approx),fill='#153C46',alpha=.25)+
  geom_line(data=future_plot,aes(year,point_forecast),color='#EE7803',linetype=2,linewidth=.9)+
  geom_vline(xintercept=2021,linetype=3,color='grey50')+
  scale_x_continuous(breaks=c(1990,2000,2010,2021,2030))+
  labs(x='Year',y='Deaths per 1,000 live births',title='Global neonatal infection mortality and forecast')
save_plot(p1,'Figure3a',9,5.5)
age_pal <- c('0-6 days'='#3371AE','7-27 days'='#E77C8E')
p2 <- ggplot(composition,aes(year,share*100,color=age_name))+geom_line(linewidth=.9)+
  scale_color_manual(values=age_pal)+scale_y_continuous(limits=c(0,100),breaks=seq(0,100,20))+
  scale_x_continuous(breaks=c(1990,2000,2010,2021))+
  labs(x='Year',y='Share of cause-specific neonatal deaths (%)',title='Early and late neonatal historical composition')
save_plot(p2,'Figure3b',8,5)
labels <- c(naive='Naive',drift='Drift',damped_ETS='Damped ETS',local_linear_trend='Local linear trend',ARIMA011='ARIMA(0,1,1)',nested_selection='Nested selection pipeline')
scores$label <- labels[scores$method]
p3 <- ggplot(scores,aes(MAE,reorder(label,MAE),fill=method=='nested_selection'))+
  geom_col(width=.65)+scale_fill_manual(values=c('FALSE'='#3371AE','TRUE'='#E77C8E'))+
  guides(fill='none')+scale_x_continuous(expand=expansion(mult=c(0,.08)))+
  labs(x='Rolling-origin MAE (deaths per 1,000 live births)',y=NULL,title='Global total forecast validation')
save_plot(p3,'Figure3c',9,5)
writeLines(c(
  'Figure 3. Global neonatal infection mortality: historical patterns, forecasting, and validation.',
  '(a) Global cause-specific deaths per 1,000 live births for neonatal sepsis and other neonatal infections, 1990-2021, and forecasts for 2022-2030. Solid and dashed lines indicate historical point estimates and conditional forecast means, respectively. The vertical dotted line marks 2021. Bands are approximate 95% simulation intervals, not official GBD joint-draw uncertainty intervals.',
  paste0('(b) Historical shares of cause-specific neonatal deaths in the early (0-6 days) and late (7-27 days) periods. Total estimated deaths: ',format(round(check$`<28 days`[check$year==1990]),big.mark=','),' in 1990 and ',format(round(check$`<28 days`[check$year==2021]),big.mark=','),' in 2021.'),
  '(c) Rolling-origin mean absolute error (MAE) for global total-rate forecasts. Eight origins (2005-2012) and horizons of 1-9 years yield 72 overlapping origin-horizon comparisons per method, not 72 independent years. Pink denotes the nested model-selection pipeline; blue denotes individual models. Smaller MAE indicates lower prediction error.',
  'Approximate input simulation assumes marginal lognormal distributions, annual Gaussian AR(1) error correlation of 0.9, and zero death-birth error correlation in the central scenario. Alternative correlations are evaluated in sensitivity analyses. These assumptions and their limitations must also be described in Methods.'
),file.path(notes,'Figure3_legend_for_manuscript.txt'))
capture.output(sessionInfo(),file=file.path(notes,'sessionInfo_total_forecast.txt'))
writeLines(c(paste('Final model:',chosen),
  'Total <28-day global rate is modelled directly; age groups are historical descriptive results only.',
  'Point forecasts are conditional means on the original GBD point series; do not confuse them with simulation means.',
  'Input distributions: marginal lognormal, matched to source means and log interval widths.',
  'Central assumed Gaussian temporal correlation: AR(1) rho=0.9; death-birth error correlation=0.',
  'Sensitivity: temporal rho=0,0.5,0.99 and death-birth correlation=-0.5,+0.5.',
  'These are approximate simulation intervals, NOT official GBD joint-draw UIs or guaranteed calibrated intervals.',
  'Historical GBD means are modelled; rolling outcomes are not independent observations.',
  'Model-only validation coverage is reported separately; wider input bands are not used to claim improved validation.',
  'Short overlapping retrospective holdouts and model selection uncertainty limit inference.',
  'Future simulations provide pointwise marginals, not coherent joint paths; no path-level risk is estimated.',
  'External official forecast comparison remains unperformed; final manuscript must disclose this.'),file.path(notes,'total_forecast_methods.txt'))
print(scores);print(final$scores);print(endpoint)
