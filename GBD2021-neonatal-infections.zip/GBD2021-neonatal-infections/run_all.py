"""Run the production analysis after obtaining the documented source data."""
import os
import shutil
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
env=os.environ.copy();env['GBD_REPO_ROOT']=str(ROOT);env['GBD_STAGE']='prepare'
rscript=shutil.which('Rscript')
if not rscript:raise SystemExit('Rscript is required. Install R and the documented R packages first.')
def run(command):
    print('RUN: '+' '.join(str(x) for x in command),flush=True)
    subprocess.run([str(x) for x in command],cwd=ROOT,env=env,check=True)
run([sys.executable,ROOT/'scripts/prepare_inputs.py'])
for n in (1,2,4,5,6,3):run([rscript,ROOT/f'assets/Figure{n}/Figure{n}.R'])
run([rscript,ROOT/'scripts/complete_uncertainty_analysis.R'])
run([sys.executable,ROOT/'scripts/build_external_comparison_tables.py'])
run([rscript,ROOT/'scripts/render_final_figures.R'])
run([sys.executable,ROOT/'scripts/prepare_final_excel_tables.py'])
run([sys.executable,ROOT/'scripts/export_formal_tables.py'])
run([sys.executable,ROOT/'scripts/validate_figure3_total.py'])
run([sys.executable,ROOT/'scripts/validate_final_outputs.py'])
print('Finished. Outputs are in assets/; validation reports are local under scripts/.')
