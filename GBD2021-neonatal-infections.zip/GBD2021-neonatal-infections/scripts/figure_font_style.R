publication_font <- function(p,w,h) {
  if(!is.null(p$labels$title)) p <- p+labs(title=stringr::str_wrap(p$labels$title,width=floor(w*6)))
  if(!is.null(p$labels$caption)) p <- p+labs(caption=stringr::str_wrap(p$labels$caption,width=floor(w*7)))
  if(!is.null(p$labels$x) && is.character(p$labels$x)) p <- p+labs(x=stringr::str_wrap(p$labels$x,width=48))
  if(!is.null(p$labels$y) && is.character(p$labels$y)) p <- p+labs(y=stringr::str_wrap(p$labels$y,width=48))
  if(is.null(p$labels$title) && exists('figure') && figure==4) p <- p+labs(title='High-to-low SDI mortality ratio')
  p <- p+theme(text=element_text(family='Arial',size=18),
    plot.title=element_text(family='Arial',size=18,face='bold',hjust=.5,margin=margin(b=14)),
    plot.title.position='plot',plot.subtitle=element_text(family='Arial',size=18,hjust=.5),
    axis.text=element_text(family='Arial',size=18),axis.title=element_text(family='Arial',size=18),
    axis.text.x=element_text(family='Arial',size=18),axis.text.y=element_text(family='Arial',size=18),
    axis.title.x=element_text(family='Arial',size=18,margin=margin(t=12)),
    axis.title.y=element_text(family='Arial',size=18,margin=margin(r=12)),
    legend.text=element_text(family='Arial',size=18),legend.title=element_blank(),
    strip.text=element_text(family='Arial',size=18),plot.caption=element_text(family='Arial',size=18,hjust=0),
    plot.margin=margin(24,32,24,28),legend.key.size=grid::unit(.65,'cm'))
  if(exists('figure') && figure %in% c(2,4)) p <- p+guides(
    colour=guide_legend(nrow=1,byrow=TRUE))
  if(inherits(p$coordinates,'CoordSf')) p <- p+theme(
    axis.text=element_blank(),axis.text.x=element_blank(),axis.text.y=element_blank(),
    axis.title=element_blank(),axis.title.x=element_blank(),axis.title.y=element_blank(),
    legend.title=element_text(family='Arial',size=18))
  for(i in seq_along(p$layers)) {
    if(inherits(p$layers[[i]]$geom,'GeomText') || inherits(p$layers[[i]]$geom,'GeomLabel')) {
      p$layers[[i]]$aes_params$family <- 'Arial'
      p$layers[[i]]$aes_params$size <- 18/ggplot2::.pt
    }
  }
  p
}
