import csv
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT/'assets'
TMP=ROOT/'scripts/table_payload'
TMP.mkdir(parents=True,exist_ok=True)
DIRS={i:next(BASE.glob(f'Table_S{i}_*'))for i in range(1,6)}
sources={}

def read(i,stem):
 p=DIRS[i]/f'Data_{stem}.csv'
 return readpath(p)

def readpath(p):
 sources[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))

def fmt(x,n=2):
 return f'{float(x):.{n}f}'

def ci(v,l,u,n=2):
 return f'{fmt(v,n)} ({fmt(l,n)} to {fmt(u,n)})'

def rank_limit(v):
 return fmt(v,3).rstrip('0').rstrip('.')

SI='SI, approximate 95% simulation interval. Derived intervals were reconstructed from published input summaries under the stated dependence assumptions; they are not official Institute for Health Metrics and Evaluation (IHME) joint-draw uncertainty intervals.'
COMMON='The cause is neonatal sepsis and other neonatal infections. Both sexes are combined; neonatal deaths refer to ages 0-27 days unless another window is specified. GBD, Global Burden of Disease.'
books=[]

def book(i,title,headers,rows,notes,widths):
 assert all(len(r)==len(headers)for r in rows)
 books.append(dict(number=i,title=title,headers=headers,rows=rows,notes=notes,widths=widths,path=str(DIRS[i]/f'{DIRS[i].name}.xlsx')))

rates=read(1,'global_continent_SDI_endpoints')
reds={(r['group_type'],r['group']):r for r in read(1,'group_1990_2021_reductions')}
gr=read(1,'global_1990_2021_reduction')[0]
order={'Global':0,'Africa':1,'Asia':2,'Americas':3,'Oceania':4,'Europe':5,'Low SDI':6,'Low-middle SDI':7,'Middle SDI':8,'High-middle SDI':9,'High SDI':10}
rows=[]
for r in sorted(rates,key=lambda r:(order[r['group']],int(r['year']))):
 red=gr if r['group']=='Global'else reds[(r['group_type'],r['group'])]
 rows.append([r['group'],int(r['year']),'0-27',float(r['deaths']),float(r['births']),ci(r['rate'],r['lower_approx'],r['upper_approx']),'--',ci(red['reduction_percent'],red['reduction_lower_approx'],red['reduction_upper_approx'],1)if r['year']=='2021'else'--'])
for r in read(1,'historical_age_counts_shares'):
 if r['year']in('1990','2021'):
  rows.append(['Global',int(r['year']),r['age_name'].replace(' days',''),float(r['deaths']),float(r['births']),fmt(r['rate']),fmt(100*float(r['share']),1),'--'])
book(1,'Global, continental and sociodemographic mortality estimates in 1990 and 2021',
 ['Population','Year','Age (days)','Estimated deaths','Live births','Mortality per 1,000 live births (95% SI)','Death share (%)','Reduction, 1990-2021 (95% SI), %'],rows,
 [COMMON,SI,'SDI, Sociodemographic Index. Country membership is fixed by 2021 SDI. These national reaggregations are not native GBD SDI aggregates. The Americas combine North and South America.',
 'Rates are ratios of death-count and live-birth means. Global totals use separate published Global series and need not equal country sums. Counts are model estimates displayed to the nearest whole number; rates and changes use unrounded inputs.',
 'Reduction = 100 x (1 - rate in 2021 / rate in 1990). Positive values indicate declining mortality. Reduction appears only in the 2021 row. Age-window death shares use total deaths from this cause at ages 0-27 days; age-window rates and shares are point estimates without derived intervals. --, not applicable or not estimated.'],[30,10,12,19,22,30,15,32])

country=read(2,'country_endpoints_and_changes')
baseline={r['location_id']:r for r in country if r['year']=='1990'}
front={r['location_id']:r for r in read(4,'frontier_uncertainty_and_distances')}
rows=[]
for r in sorted([r for r in country if r['year']=='2021'],key=lambda r:int(r['rank_point'])):
 b=baseline[r['location_id']]; f=front[r['location_id']]
 rows.append([r['location_name'],f"{int(r['rank_point'])} ({rank_limit(r['rank_lower_approx'])} to {rank_limit(r['rank_upper_approx'])})",ci(b['rate'],b['lower_approx'],b['upper_approx']),ci(r['rate'],r['lower_approx'],r['upper_approx']),ci(r['reduction_percent'],r['reduction_lower_approx'],r['reduction_upper_approx'],1),ci(f['distance_point'],f['distance_lower_approx'],f['distance_upper_approx'])])
contrasts=read(2,'top_three_rate_contrasts')
pair_note='Paired 2021 rate differences per 1,000 live births (first country minus second; 95% SI): '+ '; '.join(f"{r['country_a']} versus {r['country_b']}, {ci(r['point_estimate'],r['lower_approx'],r['upper_approx'],3)}"for r in contrasts)+'. All three intervals include zero.'
book(2,'Country mortality, historical reductions, ranking uncertainty and frontier distances',
 ['Country or territory','2021 rank (95% range)','1990 mortality (95% SI)','2021 mortality (95% SI)','Reduction, 1990-2021 (95% SI), %','2021 frontier distance (95% SI)'],rows,
 [COMMON,SI,'Mortality rates and frontier distances are expressed as deaths per 1,000 live births. Reduction = 100 x (1 - 2021 rate / 1990 rate); negative values denote increases.',
 'Countries are ordered by 2021 point mortality. Rank 1 is highest. Rank ranges are the 2.5th and 97.5th simulated-rank percentiles, not established statistically distinct positions. Interpolated percentile limits can be non-integers.',
 pair_note,'The frontier is the minimum rate among countries with equal or lower 2021 Sociodemographic Index. Distances are descriptive differences, not estimated preventable deaths.'],[42,25,31,31,34,32])

rows=[]
names={'ARIMA011':'ARIMA(0,1,1) with drift','damped_ETS':'Damped exponential smoothing','drift':'Random walk with drift','local_linear_trend':'Local linear trend','naive':'Naive','nested_selection':'Nested model-selection procedure'}
for r in sorted(read(3,'forecast_validation'),key=lambda r:float(r['MAE'])):
 rows.append(['Validation: '+names[r['method']],'Outer origins 2005-2012',fmt(r['MAE'],3)+' / '+fmt(r['RMSE'],3),100*float(r['model_only_coverage']),float(r['mean_interval_score']),'--','--'])
endpoint=readpath(BASE/'Figure3/Figure3_analysis_2030_endpoint.csv')[0]
rows.append(['Primary forecast: damped exponential smoothing','1990-2021','--','--','--',ci(endpoint['rate_point'],endpoint['rate_lower_approx'],endpoint['rate_upper_approx']),ci(endpoint['change_percent_point'],endpoint['change_lower_approx'],endpoint['change_upper_approx'],1)])
for r in read(3,'forecast_window_sensitivity'):
 if r['year']=='2030':rows.append(['Fitting-window sensitivity (model-only interval)',f"{r['train_start']}-{r['train_end']}",'--','--','--',ci(r['point'],r['lower_model_only'],r['upper_model_only']),'--'])
for r in read(3,'forecast_input_sensitivity'):
 if r['year']=='2030':rows.append([f"Input sensitivity: rhoT={r['rho_time']}, rhoDB={r['rho_death_birth']} (simulation mean)",'1990-2021','--','--','--',ci(r['simulation_mean'],r['lower_approx'],r['upper_approx']),'--'])
book(3,'Global forecast validation, the 2030 projection and sensitivity analyses',
 ['Analysis and model or scenario','Training or validation period','MAE / RMSE','Coverage (%)','Interval score','2030 mortality (interval)','2030 change from 2021 (95% SI), %'],rows,
 [COMMON,SI,'MAE, mean absolute error; RMSE, root mean squared error; ARIMA, autoregressive integrated moving average. Errors and mortality are in deaths per 1,000 live births. Lower errors and interval scores indicate better performance.',
 'Each validation row uses 72 overlapping origin-horizon evaluations (outer origins 2005-2012; horizons one to nine years). Coverage and scores use model-only 95% prediction intervals against historical GBD point estimates; these are not 72 independent observations.',
 'The primary forecast reports the conditional point estimate with the approximate input-plus-model interval. Change = 100 x (2030 rate / 2021 rate - 1); negative values indicate a decline, opposite to the historical-reduction convention.',
 'Fitting-window rows report conditional points and model-only 95% prediction intervals, excluding simulated input uncertainty. Input-sensitivity rows report simulation means and approximate input-plus-model intervals, not conditional point forecasts.',
 'rhoT and rhoDB denote assumed latent Gaussian temporal and death-birth correlations. The central input scenario uses 2,000 simulations; each alternative uses 600. Model class is held fixed. --, not applicable or not estimated.'],[47,29,20,15,17,33,35])

gaps={r['year']:r for r in read(4,'SDI_annual_absolute_relative_gaps')}
gchange={r['measure']:r for r in read(4,'SDI_gap_changes')}
indices={r['year']:r for r in read(4,'annual_concentration_indices')}
ichange=read(4,'concentration_index_change')[0]
rows=[]
for label,v,l,u,change,unit,n in [
 ('Low-minus-high absolute gap','absolute_gap','absolute_lower_approx','absolute_upper_approx','absolute_gap_2021_minus1990','Deaths per 1,000 live births',2),
 ('High-to-low rate ratio','high_low_point_estimate','high_low_lower_approx','high_low_upper_approx','high_low_ratio_2021_minus1990','Ratio',3),
 ('Low-to-high rate ratio','low_high_point_estimate','low_high_lower_approx','low_high_upper_approx',None,'Ratio',2)]:
 c=gchange[change]if change else None
 rows.append([label,ci(gaps['1990'][v],gaps['1990'][l],gaps['1990'][u],n),ci(gaps['2021'][v],gaps['2021'][l],gaps['2021'][u],n),ci(c['point_estimate'],c['lower_approx'],c['upper_approx'],n)if c else'--',unit])
rows.append(['Live-birth-weighted concentration index',ci(indices['1990']['point_estimate'],indices['1990']['lower_approx'],indices['1990']['upper_approx'],3),ci(indices['2021']['point_estimate'],indices['2021']['lower_approx'],indices['2021']['upper_approx'],3),ci(ichange['point_estimate'],ichange['lower_approx'],ichange['upper_approx'],3),'Dimensionless'])
top=sorted(front.values(),key=lambda r:float(r['distance_point']),reverse=True)[:5]
for r in top:rows.append(['Frontier distance: '+r['location_name'],'--',ci(r['distance_point'],r['distance_lower_approx'],r['distance_upper_approx']),'--','Deaths per 1,000 live births'])
curve=read(4,'curve_comparison_summary')[0]
assert curve['point_curves_cross']=='TRUE' and curve['simultaneous_band_entirely_positive']=='FALSE'and curve['simultaneous_band_entirely_negative']=='FALSE'
book(4,'Absolute and relative inequalities, concentration indices and selected frontier distances',
 ['Measure or country','1990 estimate (95% SI)','2021 estimate (95% SI)','Change, 2021 minus 1990 (95% SI)','Units'],rows,
 [COMMON,SI,'Sociodemographic Index country groups are fixed by 2021 membership. A smaller absolute gap indicates narrowing absolute inequality; a smaller high-to-low ratio indicates widening relative inequality.',
 'The concentration index ranks countries by annual Sociodemographic Index and weights the distribution by live births. Negative values indicate concentration in lower-index countries relative to births.',
 'The 1990 and 2021 concentration curves cross. The approximate 95% simultaneous band for their difference is neither entirely positive nor entirely negative across the evaluated grid; this does not establish a consistent ordering and is not a formally calibrated dominance test.',
 'The five largest point-estimated 2021 frontier distances are displayed, not statistically distinct ranks. Distances for all 204 countries and territories are provided in Table S2. These are descriptive benchmarks, not preventable mortality estimates. --, not applicable or not estimated.'],[49,31,31,37,30])

rows=[]
scenario_names={'central':'Central: rhoT=0.9, rhoC=0.5, rhoDB=0','country_independent':'Cross-country independence: rhoC=0','country_high':'High cross-country correlation: rhoC=0.9','time_independent':'Temporal independence: rhoT=0','time_moderate':'Moderate temporal correlation: rhoT=0.5','time_high':'High temporal correlation: rhoT=0.99','death_birth_negative':'Negative death-birth correlation: rhoDB=-0.5','death_birth_positive':'Positive death-birth correlation: rhoDB=0.5'}
metric_names={'concentration_index_2021_minus1990':('Concentration-index change','Dimensionless',3),'absolute_gap_2021_minus1990':('Absolute SDI-gap change','Deaths per 1,000 live births',2),'high_low_ratio_2021_minus1990':('High-to-low SDI ratio change','Ratio difference',3)}
for r in read(5,'dependence_assumption_sensitivity'):
 if r['measure']not in metric_names:continue
 label,unit,n=metric_names[r['measure']]
 rows.append(['Input dependence',scenario_names[r['scenario']],label,ci(r['point_estimate'],r['lower_approx'],r['upper_approx'],n),unit])
cut=read(5,'country_selection_cutoffs')
for n in('20','30','40','50'):
 first=min([r for r in cut if r['selection_top_n']==n],key=lambda r:float(r['reduction_percent']))
 rows.append(['Country selection',f'Highest {n} point rates in 2021','Smallest reduction: '+first['location_name'],fmt(first['reduction_percent'],1),'Percent; point estimate'])
first=min(read(5,'baseline_country_selection'),key=lambda r:float(r['reduction_percent']))
rows.append(['Country selection','Highest 30 point rates in 1990','Smallest reduction: '+first['location_name'],fmt(first['reduction_percent'],1),'Percent; point estimate'])
for r in read(5,'equal_weight_and_LOO_indices'):
 if r['year']not in('1990','2021'):continue
 rows.append(['Alternative weighting',r['year'],'Equal-country-weight mortality-rate index',fmt(r['index_country_equal_weighted'],3),'Dimensionless; point estimate'])
 rows.append(['Country exclusion',r['year'],'Live-birth-weighted index exclusion range',fmt(r['leave_one_out_min'],3)+' to '+fmt(r['leave_one_out_max'],3),'Sensitivity range; not a confidence interval'])
for r in read(5,'frontier_LOO_sensitivity'):
 if r['location_name']=='Sierra Leone':rows.append(['Country exclusion','Frontier at Sierra Leone 2021 index','Original benchmark; exclusion range',fmt(r['frontier'])+'; '+fmt(r['LOO_frontier_min'])+' to '+fmt(r['LOO_frontier_max']),'Deaths per 1,000 live births; not a confidence interval'])
for r in read(5,'UNICEF_global_historical_context'):
 if r['year']in('1990','2021'):
  rows.append(['External magnitude check','Global, '+r['year'],'GBD cause-specific / UN IGME all-cause rate',fmt(r['gbd_specific_cause_per1000'])+' / '+fmt(r['UNICEF_all_cause_per1000']),'Deaths per 1,000 live births; point estimates'])
for r in read(5,'published_study_comparison'):
 name=r['paper']+', '+r['year']
 rows.append(['Published comparison',name,'Native age-specific population rate'if r['paper'].startswith('Mu')else'Age-standardized population rate',ci(r['published_point'],r['published_lower'],r['published_upper'],3)if r['published_lower']else fmt(r['published_point']), 'Per 100,000 population; not per live births'])
book(5,'Sensitivity analyses and external mortality comparisons',
 ['Analysis','Scenario or population','Outcome','Estimate (95% SI or stated range)','Units and interpretation'],rows,
 [SI,'SDI, Sociodemographic Index; GBD, Global Burden of Disease; UN IGME, United Nations Inter-agency Group for Child Mortality Estimation. Changes are 2021 minus 1990. Historical reductions are percentages, with negative values indicating increases.',
 'rhoT, rhoC and rhoDB are assumed latent Gaussian temporal, cross-country and death-birth correlations. Alternative scenarios change one central assumption at a time. Central simulations: 4,000; each alternative: 1,200. Dependence is specified, not estimated from marginal summaries.',
 'Country-selection results identify the smallest point-estimated reduction only within the named candidate set, not the slowest progress worldwide. Modelled changes and ranking remain uncertain.',
 'Leave-one-country-out minima and maxima are sensitivity ranges, not confidence intervals. The empirical frontier is descriptive and is not a causal estimate of achievable mortality.',
 'UN IGME data were retrieved on November 1, 2026. All-cause comparisons assess magnitude only; cause coverage, estimation framework, data vintage and birth denominators differ. They do not independently validate GBD cause-specific mortality.',
 'Mu et al. (2025) reported compatible native GBD population-rate values that agree with the retained source at published precision; this is same-source concordance, not independent validation. Their values must not be converted to live-birth rates by rescaling.',
 'Jiang et al. (2025) reported age-standardized mortality, a different quantity from the primary live-birth indicator; corresponding published interval bounds were not available in the retained comparison data. Source publications are identified in the main-text references.'],[29,55,49,38,55])

payload={'books':books,'sources':sources,'source_files_unchanged':True,'primary_forecast':endpoint}
(TMP/'payload.json').write_text(json.dumps(payload,ensure_ascii=False,allow_nan=False),encoding='utf-8')
print([(b['number'],len(b['rows']),len(b['headers']))for b in books])
