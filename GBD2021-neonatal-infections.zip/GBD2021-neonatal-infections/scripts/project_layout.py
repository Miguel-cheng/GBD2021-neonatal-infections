"""Locate the user-managed figure container without relying on its spelling."""
from pathlib import Path

def figure_assets_root(revision):
    matches = [p for p in Path(revision).iterdir() if p.is_dir() and all(
        (p / f'Figure{n}' / f'Figure{n}.R').is_file() for n in range(1, 7))]
    if len(matches) != 1:
        raise RuntimeError(f'Expected one six-figure container, found {matches}')
    return matches[0]
