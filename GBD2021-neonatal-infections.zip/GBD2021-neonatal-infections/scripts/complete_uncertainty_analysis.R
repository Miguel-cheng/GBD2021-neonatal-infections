suppressPackageStartupMessages({library(data.table);library(matrixStats);library(jsonlite)})
args <- commandArgs(FALSE)
file_arg <- sub('^--file=','',args[grepl('^--file=',args)])
file_arg <- gsub('~+~',' ',file_arg,fixed=TRUE)
revroot <- if(length(file_arg)) dirname(dirname(normalizePath(file_arg[1]))) else
  Sys.getenv('GBD_REPO_ROOT', unset=getwd())
notes <- file.path(revroot,'scripts')
source(file.path(notes,'project_layout.R'))
assets <- figure_assets_root(revroot)
source(file.path(notes,'supplementary_path.R'))
paths <- function(fig,name) file.path(assets,paste0('Figure',fig),name)
export <- function(x,fig,name,supp=FALSE) {
  target <- if(supp) supplementary_path(revroot,name) else file.path(assets,paste0('Figure',fig),name)
  p <- dirname(target)
  dir.create(p,recursive=TRUE,showWarnings=FALSE)
  fwrite(x,target,bom=TRUE)
}
uncertainty_label <- 'Approximate 95% simulation interval; not official IHME joint-draw UI'
d <- fread(paths(6,'Figure6_analysis_country_age_year_master.csv'))[age_name=='<28 days']
setorder(d,year,location_id)
ids <- sort(unique(d$location_id)); years <- 1990:2021; nc <- length(ids); ny <- length(years)
stopifnot(nc==204,ny==32,nrow(d)==nc*ny,!anyDuplicated(d[,.(location_id,year)]))
for(y in years) stopifnot(identical(d[year==y,location_id],ids))
stopifnot(all(is.finite(as.matrix(d[,.(deaths,deaths_lower,deaths_upper,births,births_lower,births_upper,sdi)]))),
  all(d$deaths_lower>0),all(d$births_lower>0))
metadata <- d[year==1990,.(location_id,location_name,continent,iso3)]
membership <- fread(paths(4,'Figure4_analysis_country_SDI_membership.csv'))
metadata <- merge(metadata,membership[,.(location_id,SDI_group)],by='location_id',sort=FALSE)
metadata <- metadata[match(ids,location_id)]
stopifnot(nrow(metadata)==nc,!anyNA(metadata))
d <- merge(d,metadata[,.(location_id,SDI_group)],by='location_id',sort=FALSE)
setorder(d,year,location_id)
asmat <- function(field) matrix(d[[field]],nc,ny)
dm <- asmat('deaths'); bm <- asmat('births'); rates <- dm/bm*1000; sdi <- asmat('sdi')
sdD <- (log(asmat('deaths_upper'))-log(asmat('deaths_lower')))/(2*qnorm(.975))
sdB <- (log(asmat('births_upper'))-log(asmat('births_lower')))/(2*qnorm(.975))
muD <- log(dm)-sdD^2/2; muB <- log(bm)-sdB^2/2
orders <- lapply(seq_len(ny),function(t) order(sdi[,t],ids))
blocks <- lapply(seq_len(ny),function(t) rle(sdi[orders[[t]],t])$lengths)
continents <- c('Africa','Americas','Asia','Europe','Oceania')
sdigroups <- c('Low SDI','Low-middle SDI','Middle SDI','High-middle SDI','High SDI')
groups <- data.table(group_type=c(rep('continent',5),rep('SDI_country_group',5)),group=c(continents,sdigroups))
A <- sapply(seq_len(nrow(groups)),function(g) if(groups$group_type[g]=='continent')
  as.numeric(metadata$continent==groups$group[g]) else as.numeric(metadata$SDI_group==groups$group[g]))
gdpoint <- crossprod(A,dm); gbpoint <- crossprod(A,bm); grpoint <- 1000*gdpoint/gbpoint
group_grid <- rbindlist(lapply(seq_len(ny),function(t) copy(groups)[,year:=years[t]]))
country_grid <- copy(d[,.(location_id,location_name,year,continent,SDI_group,deaths,deaths_lower,deaths_upper,births,births_lower,births_upper,rate,sdi)])
summ <- function(draws,point) {
  qs <- rowQuantiles(draws,probs=c(.025,.975),drop=FALSE)
  data.table(point_estimate=as.numeric(point),lower_approx=qs[,1],upper_approx=qs[,2],simulation_mean=rowMeans(draws))
}
curve_info <- function(D,B,t,grid) {
  o <- orders[[t]]; w <- B[o]/sum(B); burden <- D[o]/sum(D)
  lens <- blocks[[t]]
  if(length(lens)<nc) {
    k <- rep(seq_along(lens),lens)
    w <- as.numeric(rowsum(w,k,reorder=FALSE)); burden <- as.numeric(rowsum(burden,k,reorder=FALSE))
  }
  x <- c(0,cumsum(w)); z <- c(0,cumsum(burden))
  x[length(x)] <- 1;z[length(z)] <- 1
  list(index=2*sum(burden*(cumsum(w)-w/2))-1,
    curve=approx(x,z,xout=grid,ties='ordered',rule=2)$y)
}
grid <- seq(.01,.99,.01)
ci_point <- vapply(seq_len(ny),function(t) curve_info(dm[,t],bm[,t],t,grid)$index,numeric(1))
c0 <- curve_info(dm[,1],bm[,1],1,grid)$curve
c1 <- curve_info(dm[,ny],bm[,ny],ny,grid)$curve
frontier_values <- function(R,t=ny) {
  o <- orders[[t]];lens <- blocks[[t]]
  if(length(lens)==nc) value <- cummin(R[o]) else {
    k <- rep(seq_along(lens),lens)
    block_min <- vapply(split(R[o],k),min,numeric(1))
    value <- rep(cummin(block_min),lens)
  }
  result <- numeric(nc);result[o] <- value;result
}
frontier_point <- frontier_values(rates[,ny])
sdifixed <- metadata$SDI_group
lo <- match('Low SDI',groups$group); hi <- match('High SDI',groups$group)
rank_point <- rank(-rates[,ny],ties.method='min')
base_country <- data.table(location_id=ids,location_name=metadata$location_name,continent=metadata$continent,SDI_group=metadata$SDI_group)

ar_field <- function(rho_country,rho_time) {
  common <- rnorm(ny); individual <- matrix(rnorm(nc*ny),nc,ny)
  for(t in 2:ny) {
    common[t] <- rho_time*common[t-1]+sqrt(1-rho_time^2)*common[t]
    individual[,t] <- rho_time*individual[,t-1]+sqrt(1-rho_time^2)*individual[,t]
  }
  sqrt(rho_country)*matrix(rep(common,each=nc),nc,ny)+sqrt(1-rho_country)*individual
}
run_scenario <- function(label,N,rho_time,rho_country,rho_db,central=FALSE) {
  set.seed(20261101)
  rdraw <- matrix(NA_real_,nc*ny,N)
  gd <- gb <- gr <- matrix(NA_real_,10*ny,N)
  ci <- matrix(NA_real_,ny,N)
  curve0 <- curve1 <- matrix(NA_real_,length(grid),N)
  fr <- dist <- frac <- ranks <- matrix(NA_real_,nc,N)
  for(b in seq_len(N)) {
    zd <- ar_field(rho_country,rho_time)
    zb <- rho_db*zd+sqrt(1-rho_db^2)*ar_field(rho_country,rho_time)
    D <- exp(muD+sdD*zd); B <- exp(muB+sdB*zb); R <- D/B*1000
    rdraw[,b] <- as.vector(R)
    DD <- crossprod(A,D);BB <- crossprod(A,B)
    gd[,b] <- as.vector(DD);gb[,b] <- as.vector(BB);gr[,b] <- as.vector(DD/BB*1000)
    for(t in seq_len(ny)) {
      z <- curve_info(D[,t],B[,t],t,grid)
      ci[t,b] <- z$index
      if(t==1) curve0[,b] <- z$curve
      if(t==ny) curve1[,b] <- z$curve
    }
    f <- frontier_values(R[,ny])
    fr[,b] <- f;dist[,b] <- R[,ny]-f;frac[,b] <- dist[,b]/R[,ny]
    ranks[,b] <- rank(-R[,ny],ties.method='first')
    if(b%%500==0) message(label,': ',b,'/',N)
  }
  stopifnot(all(is.finite(rdraw)),all(rdraw>0),all(abs(ci)<=1+1e-8),all(dist>=-1e-10))
  country_ui <- cbind(copy(country_grid),summ(rdraw,as.vector(rates))[,.(lower_approx,upper_approx,simulation_mean)])
  country_change <- cbind(copy(base_country),summ(100*(1-rdraw[((ny-1)*nc+1):(ny*nc),]/rdraw[1:nc,]),100*(1-rates[,ny]/rates[,1])))
  setnames(country_change,c('point_estimate','lower_approx','upper_approx','simulation_mean'),
    c('reduction_percent','reduction_lower_approx','reduction_upper_approx','reduction_simulation_mean'))
  group_ui <- cbind(copy(group_grid),deaths=as.vector(gdpoint),births=as.vector(gbpoint),rate=as.vector(grpoint),
    summ(gr,as.vector(grpoint))[,.(lower_approx,upper_approx,simulation_mean)])
  gap <- cbind(data.table(year=years),summ(gr[seq(lo,10*ny,10),]-gr[seq(hi,10*ny,10),],grpoint[lo,]-grpoint[hi,]))
  setnames(gap,c('point_estimate','lower_approx','upper_approx','simulation_mean'),c('absolute_gap','absolute_lower_approx','absolute_upper_approx','absolute_simulation_mean'))
  ratioHL <- summ(gr[seq(hi,10*ny,10),]/gr[seq(lo,10*ny,10),],grpoint[hi,]/grpoint[lo,])
  ratioLH <- summ(gr[seq(lo,10*ny,10),]/gr[seq(hi,10*ny,10),],grpoint[lo,]/grpoint[hi,])
  setnames(ratioHL,names(ratioHL),paste0('high_low_',names(ratioHL)))
  setnames(ratioLH,names(ratioLH),paste0('low_high_',names(ratioLH)))
  gap <- cbind(gap,ratioHL,ratioLH)
  absdraw <- gr[seq(lo,10*ny,10),]-gr[seq(hi,10*ny,10),]
  hldraw <- gr[seq(hi,10*ny,10),]/gr[seq(lo,10*ny,10),]
  gapchange <- rbind(
    cbind(data.table(measure='absolute_gap_2021_minus1990'),summ(matrix(absdraw[ny,]-absdraw[1,],1),tail(gap$absolute_gap,1)-gap$absolute_gap[1])),
    cbind(data.table(measure='high_low_ratio_2021_minus1990'),summ(matrix(hldraw[ny,]-hldraw[1,],1),tail(gap$high_low_point_estimate,1)-gap$high_low_point_estimate[1])))
  ci_ui <- cbind(data.table(year=years),summ(ci,ci_point))
  ci_change <- cbind(data.table(measure='concentration_index_2021_minus1990'),summ(matrix(ci[ny,]-ci[1,],1),ci_point[ny]-ci_point[1]))
  cdelta <- curve1-curve0
  delta_summary <- summ(cdelta,c1-c0)
  sd_delta <- rowSds(cdelta);means_delta <- rowMeans(cdelta)
  standardized <- sweep(sweep(cdelta,1,c1-c0,'-'),1,pmax(sd_delta,1e-12),'/')
  critical <- unname(quantile(colMaxs(abs(standardized)),.95))
  curve_table <- cbind(data.table(cumulative_birth_share=grid,curve_1990=c0,curve_2021=c1),
    delta_summary[,.(difference_2021_minus1990=point_estimate,lower_pointwise_approx=lower_approx,upper_pointwise_approx=upper_approx)])
  curve_table[,`:=`(lower_simultaneous_approx=pmax(-1,(c1-c0)-critical*sd_delta),
    upper_simultaneous_approx=pmin(1,(c1-c0)+critical*sd_delta),
    simulation_fraction_difference_positive=rowMeans(cdelta>0))]
  frontier_ui <- cbind(copy(base_country),sdi2021=sdi[,ny],rate_point=rates[,ny],
    summ(fr,frontier_point)[,.(frontier_point=point_estimate,frontier_lower_approx=lower_approx,frontier_upper_approx=upper_approx)],
    summ(dist,rates[,ny]-frontier_point)[,.(distance_point=point_estimate,distance_lower_approx=lower_approx,distance_upper_approx=upper_approx)],
    summ(frac,(rates[,ny]-frontier_point)/rates[,ny])[,.(distance_fraction_point=point_estimate,distance_fraction_lower_approx=lower_approx,distance_fraction_upper_approx=upper_approx)])
  frontier_ui[,simulation_fraction_on_frontier:=rowMeans(dist<1e-12)]
  rq <- rowQuantiles(ranks,probs=c(.025,.975))
  ranking <- cbind(copy(base_country),data.table(rank_point=rank_point,rank_lower_approx=rq[,1],rank_upper_approx=rq[,2],
    simulation_fraction_top10=rowMeans(ranks<=10),simulation_fraction_top30=rowMeans(ranks<=30)))
  tag <- function(x) copy(x)[,`:=`(scenario=label,rho_time=rho_time,rho_country=rho_country,rho_death_birth=rho_db,n_simulations=N,interval_type=uncertainty_label)]
  # Compact sensitivity outputs compare the same estimands under alternative covariance assumptions.
  sens <- rbindlist(list(
    tag(ci_change)[,.(scenario,measure,point_estimate,lower_approx,upper_approx,rho_time,rho_country,rho_death_birth,n_simulations)],
    tag(gapchange)[,.(scenario,measure,point_estimate,lower_approx,upper_approx,rho_time,rho_country,rho_death_birth,n_simulations)],
    tag(group_ui[year==2021])[,.(scenario,measure=paste0(group_type,':',group,':2021_rate'),point_estimate=rate,lower_approx,upper_approx,rho_time,rho_country,rho_death_birth,n_simulations)]),fill=TRUE)
  sens[,interval_type:=uncertainty_label]
  append_supp <- function(x,fig,name) {
    target <- supplementary_path(revroot,name)
    fwrite(tag(x),target,append=!central,bom=central)
  }
  append_supp(country_change,5,'Table_S9b_country_change_dependence_sensitivity.csv')
  append_supp(country_ui[year %in% c(1990,2021)],5,'Table_S9g_country_endpoint_dependence_sensitivity.csv')
  append_supp(ranking,5,'Table_S9h_rank_dependence_sensitivity.csv')
  append_supp(gap,4,'Table_S9c_SDI_gap_dependence_sensitivity.csv')
  append_supp(frontier_ui,6,'Table_S9d_frontier_dependence_sensitivity.csv')
  append_supp(ci_ui,6,'Table_S9e_index_dependence_sensitivity.csv')
  append_supp(curve_table,6,'Table_S9f_curve_comparison_dependence_sensitivity.csv')
  if(central) {
    country_ui[,interval_type:=uncertainty_label];country_change[,interval_type:=uncertainty_label]
    group_ui[,interval_type:=uncertainty_label];gap[,interval_type:=uncertainty_label]
    ci_ui[,interval_type:=uncertainty_label];frontier_ui[,interval_type:=uncertainty_label]
    for(fig in c(1,2,5,6)) export(country_ui,fig,paste0('Figure',fig,'_analysis_country_rate_intervals.csv'))
    for(fig in c(1,2)) export(group_ui[group_type=='continent'],fig,paste0('Figure',fig,'_analysis_continent_rate_intervals.csv'))
    export(country_change,5,'Figure5_analysis_country_change_intervals.csv')
    export(group_ui[group_type=='SDI_country_group'],4,'Figure4_analysis_SDI_rate_intervals.csv')
    export(gap,4,'Figure4_analysis_gap_intervals.csv');export(tag(gapchange),4,'Table_S4_SDI_gap_changes.csv',TRUE)
    export(ci_ui,6,'Figure6_analysis_concentration_index_intervals.csv')
    export(tag(ci_change),6,'Table_S5b_concentration_index_change.csv',TRUE)
    export(tag(curve_table),6,'Table_S6_concentration_curve_comparison.csv',TRUE)
    export(tag(frontier_ui),6,'Table_S7_frontier_uncertainty_and_distances.csv',TRUE)
    export(frontier_ui,6,'Figure6_analysis_frontier_input_uncertainty.csv')
    curves_with_ui <- rbind(
      cbind(data.table(year=1990,cumulative_birth_share=grid),summ(curve0,c0)),
      cbind(data.table(year=2021,cumulative_birth_share=grid),summ(curve1,c1)))
    export(tag(curves_with_ui),6,'Figure6_analysis_curve_uncertainty.csv')
    export(ci_ui,6,'Table_S5a_annual_concentration_indices.csv',TRUE)
    export(tag(curve_table[,.(
      point_curves_cross=any(difference_2021_minus1990>0)&any(difference_2021_minus1990<0),
      simultaneous_band_entirely_positive=all(lower_simultaneous_approx>0),
      simultaneous_band_entirely_negative=all(upper_simultaneous_approx<0),
      standardized_max_critical=critical)]),6,'Table_S6b_curve_comparison_summary.csv',TRUE)
    export(tag(ranking),5,'Table_S2b_rank_uncertainty_sensitivity.csv',TRUE)
    # Main country endpoint table retains source numerator/denominator intervals alongside derived approximate intervals.
    endpoints <- merge(country_ui[year %in% c(1990,2021)],country_change,by=c('location_id','location_name','continent','SDI_group'),suffixes=c('','_change'),sort=FALSE)
    endpoints <- merge(endpoints,ranking[,.(location_id,rank_point,rank_lower_approx,rank_upper_approx,simulation_fraction_top10,simulation_fraction_top30)],by='location_id',sort=FALSE)
    export(endpoints,5,'Table_S2_country_endpoints_and_changes.csv',TRUE)
    export(group_ui[group_type=='SDI_country_group'],4,'Table_S3_SDI_country_group_annual_rates.csv',TRUE)
    export(gap,4,'Table_S4a_SDI_annual_absolute_relative_gaps.csv',TRUE)
    # Pairwise contrasts describe top-three uncertainty without asserting statistically distinct ranks.
    top3 <- order(rates[,ny],decreasing=TRUE)[1:3]
    pairs <- combn(top3,2)
    pairtab <- rbindlist(lapply(seq_len(ncol(pairs)),function(j) {
      a<-pairs[1,j];b<-pairs[2,j]
      cbind(data.table(country_a=metadata$location_name[a],country_b=metadata$location_name[b]),
        summ(matrix(rdraw[(ny-1)*nc+a,]-rdraw[(ny-1)*nc+b,],1),rates[a,ny]-rates[b,ny]))
    }))
    export(tag(pairtab),5,'Table_S2c_top_three_rate_contrasts.csv',TRUE)
    counts <- cbind(copy(group_grid),
      summ(gd,as.vector(gdpoint))[,.(deaths=point_estimate,deaths_lower_approx=lower_approx,deaths_upper_approx=upper_approx)],
      summ(gb,as.vector(gbpoint))[,.(births=point_estimate,births_lower_approx=lower_approx,births_upper_approx=upper_approx)])
    export(tag(counts),1,'Table_S1b_aggregated_count_intervals.csv',TRUE)
    export(tag(group_ui),1,'Table_S1c_all_group_annual_rates.csv',TRUE)
    groupchange <- rbindlist(lapply(1:10,function(g) {
      a<-g;b<-(ny-1)*10+g
      cbind(copy(groups[g]),summ(matrix(100*(1-gr[b,]/gr[a,]),1),100*(1-as.vector(grpoint)[b]/as.vector(grpoint)[a])))
    }))
    setnames(groupchange,c('point_estimate','lower_approx','upper_approx','simulation_mean'),
      c('reduction_percent','reduction_lower_approx','reduction_upper_approx','reduction_simulation_mean'))
    export(tag(groupchange),1,'Table_S1d_group_1990_2021_reductions.csv',TRUE)
    saveRDS(list(country_rate=rdraw,group_rate=gr,group_deaths=gd,group_births=gb,ci=ci,
      curve_1990=curve0,curve_2021=curve1,frontier=fr,distance=dist,ranks=ranks,
      country_grid=country_grid,group_grid=group_grid,scenario=label,assumptions=c(rho_time=rho_time,rho_country=rho_country,rho_db=rho_db)),
      file.path(notes,'approximate_central_draws_NOT_IHME.rds'),compress='gzip')
  }
  sens
}
scenarios <- data.table(scenario=c('central','country_independent','country_high','time_independent','time_moderate','time_high','death_birth_negative','death_birth_positive'),
  rho_time=c(.9,.9,.9,0,.5,.99,.9,.9),rho_country=c(.5,0,.9,.5,.5,.5,.5,.5),rho_db=c(0,0,0,0,0,0,-.5,.5),N=c(4000,rep(1200,7)))
all_sens <- list()
for(j in 1:nrow(scenarios)) {
  sc <- scenarios[j]
  all_sens[[j]] <- run_scenario(sc$scenario,sc$N,sc$rho_time,sc$rho_country,sc$rho_db,central=j==1)
  gc()
}
export(rbindlist(all_sens),6,'Table_S9_dependence_assumption_sensitivity.csv',TRUE)
fwrite(scenarios,file.path(notes,'uncertainty_scenarios.csv'))

# Reuse the exact global history simulations already used in Figure3.
glob <- fread(paths(3,'Figure3_analysis_verified_historical_inputs.csv'))[age_name=='<28 days'][order(year)]
global_ui <- fread(paths(3,'Figure3_analysis_historical_rate_approximate_intervals.csv'))
gdraw <- as.matrix(fread(paths(3,'Figure3_analysis_approximate_historical_draws_NOT_IHME_draws.csv'))[,paste0('rate_',years),with=FALSE])
global_change <- summ(matrix(100*(1-gdraw[,ny]/gdraw[,1]),1),100*(1-glob$rate[ny]/glob$rate[1]))
setnames(global_change,c('point_estimate','lower_approx','upper_approx','simulation_mean'),c('reduction_percent','reduction_lower_approx','reduction_upper_approx','reduction_simulation_mean'))
global_change[,`:=`(interval_type=uncertainty_label,n_simulations=nrow(gdraw),rho_time=.9,
  rho_death_birth=0,scenario='Figure3_central_official_global_inputs')]
global_ui <- merge(glob,global_ui,by='year',sort=TRUE)
global_ui[,`:=`(group_type='global_official',group='Global',interval_type=uncertainty_label)]
for(fig in c(1,2)) export(global_ui,fig,paste0('Figure',fig,'_analysis_global_rate_intervals.csv'))
export(global_change,2,'Figure2_analysis_global_historical_reduction_interval.csv')
export(global_change,1,'Table_S1e_global_1990_2021_reduction.csv',TRUE)
groupdata <- fread(supplementary_path(revroot,'Table_S1c_all_group_annual_rates.csv'))
endpoints <- rbindlist(list(global_ui[year %in% c(1990,2021),.(group_type,group,year,deaths,births,rate,lower_approx,upper_approx,interval_type)],
  groupdata[year %in% c(1990,2021),.(group_type,group,year,deaths,births,rate,lower_approx,upper_approx,interval_type)]),fill=TRUE)
export(endpoints,1,'Table_S1_global_continent_SDI_endpoints.csv',TRUE)

# Summarize already-computed robustness outputs without treating LOO ranges as UIs.
for(item in list(c(5,'Figure5_analysis_country_cutoff_sensitivity.csv','Table_S8a_country_selection_cutoffs.csv'),
                c(5,'Figure5_analysis_baseline1990_top30_selection_sensitivity.csv','Table_S8b_baseline_country_selection.csv'),
                c(6,'Figure6_analysis_concentration_indices_and_LOO_sensitivity.csv','Table_S8c_equal_weight_and_LOO_indices.csv'),
                c(6,'Figure6_analysis_frontier_country_distances_and_LOO_sensitivity.csv','Table_S8d_frontier_LOO_sensitivity.csv'),
                c(3,'Figure3_analysis_window_and_preCOVID_sensitivity.csv','Table_S8e_forecast_window_sensitivity.csv'),
                c(3,'Figure3_analysis_total_validation_scores.csv','Table_S8f_forecast_validation.csv'),
                c(3,'Figure3_analysis_input_dependence_sensitivity.csv','Table_S8g_forecast_input_sensitivity.csv'))) {
  export(fread(paths(as.integer(item[1]),item[2])),as.integer(item[1]),item[3],TRUE)
}
export(fread(paths(3,'Figure3_analysis_historical_age_composition.csv')),3,'Table_S3b_historical_age_counts_shares.csv',TRUE)

# Reconciliation is numeric, not a guessed explanation of the discrepancies.
native <- fread(paths(4,'Figure4_analysis_official_SDI_neonatal_counts.csv'))
national <- d[,.(national_deaths=sum(deaths),national_births=sum(births)),by=year]
native_sum <- native[,.(native_SDI_deaths=sum(val)),by=year]
recon <- merge(merge(national,native_sum,by='year'),glob[,.(year,official_global_deaths=deaths,official_global_births=births)],by='year')
recon[,`:=`(native_SDI_minus_national=native_SDI_deaths-national_deaths,
  global_deaths_minus_national=official_global_deaths-national_deaths,
  global_births_minus_national=official_global_births-national_births)]
export(recon,4,'Table_S11a_total_mass_reconciliation.csv',TRUE)
export(fread(paths(4,'Figure4_analysis_national_regrouping_vs_official_SDI_aggregates.csv')),4,'Table_S11b_SDI_regrouping_differences.csv',TRUE)

manifest <- list(status='All ten planned numeric computations completed under explicit approximate dependence scenarios; external checks separate.',
  intervals=uncertainty_label,central=list(N=4000,rho_time=.9,rho_country=.5,rho_death_birth=0),
  global_history='Exact reuse of Figure3 approximate simulations; global counts not forced to equal sum of countries.',
  fixed_sdi='Fixed national 2021 grouping. 182 labels direct and 22 classified by official reference boundaries.',
  curve_comparison='99 interior cumulative-birth-share grid points. Centered standardized max-deviation approximate simultaneous bands; no classical p-value or guaranteed confidence coverage.',
  limitations=c('No original IHME joint draws; all covariance assumptions unidentifiable from marginal summaries.',
    'Source marginal lognormal approximation may not exactly reproduce supplied percentile endpoints.',
    'SDI treated as fixed. Country ranks and frontier are descriptive conditional simulation quantities, not causal achievable outcomes.',
    'Simulation fractions are not frequentist p-values.',
    'Official forecast and VR metadata access may prevent external checks; do not mark them completed without data.'))
write_json(manifest,file.path(notes,'uncertainty_analysis_manifest.json'),pretty=TRUE,auto_unbox=TRUE)
capture.output(sessionInfo(),file=file.path(notes,'uncertainty_sessionInfo.txt'))
message('COMPLETED approximate country, region, SDI, change, index, curve and frontier analyses.')
