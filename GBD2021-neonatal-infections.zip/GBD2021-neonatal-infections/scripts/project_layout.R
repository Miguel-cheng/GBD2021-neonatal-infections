revision_root <- function(start=getwd()) {
  p <- normalizePath(start,mustWork=TRUE)
  if(!dir.exists(p)) p <- dirname(p)
  repeat {
    if(file.exists(file.path(p,'scripts','project_layout.R'))) return(p)
    parent <- dirname(p)
    if(identical(parent,p)) stop('Cannot find revision root from: ',start)
    p <- parent
  }
}
figure_assets_root <- function(revision_dir) {
  dirs <- list.dirs(revision_dir,recursive=FALSE,full.names=TRUE)
  valid <- dirs[vapply(dirs,function(p) all(file.exists(file.path(p,paste0('Figure',1:6),paste0('Figure',1:6,'.R')))),logical(1))]
  if(length(valid)!=1L) stop('Expected one folder containing all six Figure scripts; found ',length(valid))
  normalizePath(valid,mustWork=TRUE)
}
