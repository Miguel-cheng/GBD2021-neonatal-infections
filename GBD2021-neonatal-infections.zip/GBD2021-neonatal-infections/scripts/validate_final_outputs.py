"""Check final flat-folder tables and TIFFs without changing manuscript files."""
import csv
import json
import math
from pathlib import Path
from project_layout import figure_assets_root
from PIL import Image, ImageOps, ImageDraw

REV = Path(__file__).resolve().parent.parent
ASSETS = figure_assets_root(REV)
checks = []
for n, kind, expected in [(1, 'country', 6528), (2, 'continent', 160),
                          (4, 'SDI', 160), (5, 'country', 6528)]:
    p = ASSETS / f'Figure{n}' / f'Figure{n}_analysis_{kind}_rate_intervals.csv'
    with p.open(encoding='utf-8-sig') as f:
        rows = list(csv.DictReader(f))
    assert len(rows) == expected, (p, len(rows))
    for r in rows:
        for k in ['rate', 'lower_approx', 'upper_approx']:
            assert math.isfinite(float(r[k])) and float(r[k]) > 0, (p, r)
        assert float(r['lower_approx']) <= float(r['upper_approx'])
    checks.append({'table': str(p.relative_to(REV)), 'rows': len(rows), 'status': 'PASS'})

tiles = []
for p in sorted(list(ASSETS.glob('**/*.tif'))):
    with Image.open(p) as im:
        dpi = im.info.get('dpi', (0, 0))
        assert all(abs(d-600) < 1 for d in dpi), (p, dpi)
        assert im.info.get('compression') == 'tiff_lzw', (p, im.info)
        rgb = im.convert('RGB')
        small = ImageOps.contain(rgb, (520, 340))
        assert ImageOps.grayscale(small).getextrema()[0] < 200, p
        tile = Image.new('RGB', (560, 380), 'white')
        tile.paste(small, ((560-small.width)//2, 30))
        ImageDraw.Draw(tile).text((8, 8), p.stem, fill='black')
        tiles.append(tile)
        checks.append({'image': str(p.relative_to(REV)), 'pixels': im.size,
                       'dpi': list(map(float, dpi)), 'compression': 'LZW', 'status': 'PASS'})
sheet = Image.new('RGB', (1680, 380*((len(tiles)+2)//3)), '#dddddd')
for i, tile in enumerate(tiles):
    sheet.paste(tile, ((i % 3)*560, (i//3)*380))
sheet.save(REV/'scripts/final_figure_contact_sheet.jpg')
out = REV / 'scripts/final_output_validation.json'
out.write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'PASS: {len(checks)} table/image checks; contact sheet /tmp/final_figure_contact_sheet.jpg')
