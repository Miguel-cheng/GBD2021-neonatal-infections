args <- commandArgs(FALSE)
script <- sub('^--file=','',args[grepl('^--file=',args)])[1]
root <- dirname(dirname(normalizePath(script,mustWork=TRUE)))
Sys.setenv(GBD_REPO_ROOT=root, GBD_STAGE='final')
source(file.path(root,'scripts','render_interval_figures.R'))
for(n in c(1,2,4,5,6)) render_interval_figure(root,n)
