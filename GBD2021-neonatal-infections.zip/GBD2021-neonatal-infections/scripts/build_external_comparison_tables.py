import csv
import json
from pathlib import Path
from project_layout import figure_assets_root

REV=Path(__file__).resolve().parents[1]
ROOT=REV
ASSETS=figure_assets_root(REV)
SUP=ASSETS
PATH_MAP=json.loads((REV/'scripts/supplementary_paths.json').read_text())
def mapped(path):
    return REV/PATH_MAP[path.name] if path.name in PATH_MAP else path
def read(path):
    path=mapped(path)
    with path.open(encoding='utf-8-sig',newline='') as f:
        return list(csv.DictReader(f))
def write(path,rows):
    path=mapped(path)
    assert rows
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

unicef_url='https://sdmx.data.unicef.org/ws/public/sdmxapi/rest/data/UNICEF,GLOBAL_DATAFLOW,1.0/.CME_MRM0..?startPeriod=2021&endPeriod=2021&format=sdmx-csv&dimensionAtObservation=AllDimensions'
u=read(SUP/'UNICEF_2021_neonatal_mortality_source.csv')
u=[r for r in u if r['SEX']=='_T' and r['TIME_PERIOD']=='2021' and r['INDICATOR']=='CME_MRM0' and r['UNIT_MEASURE']=='D_PER_1000_B']
keys=[r['REF_AREA'] for r in u]
assert len(keys)==len(set(keys))
by={r['REF_AREA']:r for r in u}
assert 'WORLD' in by
countries=read(ASSETS/'Figure1/Figure1_analysis_country_rate_intervals.csv')
countries=[r for r in countries if r['year']=='2021']
geography={r['location_id']:r for r in read(ASSETS/'Figure1/Figure1_analysis_country_geography_mapping.csv')}
comparison=[]
for r in countries:
    r['iso3']=geography[r['location_id']]['iso3']
    other=by.get(r['iso3'])
    comparison.append({'location_id':r['location_id'],'location_name':r['location_name'],'iso3':r['iso3'],
      'year':2021,'gbd_specific_cause_per1000':float(r['rate']),
      'UNICEF_all_cause_per1000':float(other['OBS_VALUE']) if other else '',
      'UNICEF_source_lower':float(other['LOWER_BOUND']) if other and other['LOWER_BOUND'] else '',
      'UNICEF_source_upper':float(other['UPPER_BOUND']) if other and other['UPPER_BOUND'] else '',
      'matching_source_available':bool(other),
      'specific_cause_point_exceeds_all_cause':float(r['rate'])>float(other['OBS_VALUE']) if other else '',
      'interpretation':'Cross-source all-cause plausibility only; not independent validation of GBD cause-specific risk',
      'UNICEF_interval_level':'Not specified in downloaded CSV; not labelled 95%',
      'source_url':unicef_url,'retrieval_date':'2026-11-01'})
write(SUP/'Table_S10a_UNICEF_country_plausibility.csv',comparison)
world=by['WORLD']
g=read(ASSETS/'Figure3/Figure3_analysis_verified_historical_inputs.csv')
g2021=next(r for r in g if r['year']=='2021' and r['age_name']=='<28 days')
write(SUP/'Table_S10b_UNICEF_global_plausibility.csv',[{'year':2021,
  'gbd_specific_cause_per1000':float(g2021['rate']),'UNICEF_all_cause_per1000':float(world['OBS_VALUE']),
  'UNICEF_source_lower':float(world['LOWER_BOUND']),'UNICEF_source_upper':float(world['UPPER_BOUND']),
  'UNICEF_interval_level':'Not specified in downloaded CSV',
  'specific_cause_point_exceeds_all_cause':float(g2021['rate'])>float(world['OBS_VALUE']),
  'interpretation':'2021 estimate from current UNICEF database; not necessarily the 2021 data release. All-cause magnitude check only.',
  'source_url':unicef_url,'retrieval_date':'2026-11-01'}])

native=read(ROOT/'inputs/global_mortality.csv')
native={int(r['year']):r for r in native if r['metric_name']=='Rate' and r['age_name']=='<28 days' and r['sex_name']=='Both'}
mu={1990:(2648.993,2337.831,2953.867),2021:(2118.49,1790.393,2490.714)}
rows=[]
for year,values in mu.items():
    n=native[year]
    assert all(abs(float(n[field])-value)<.001 for field,value in zip(['val','lower','upper'],values))
    rows.append({'paper':'Mu et al. 2025','year':year,'outcome':'Neonatal sepsis and other neonatal infections mortality rate',
      'published_point':values[0],'published_lower':values[1],'published_upper':values[2],
      'published_unit':'Per 100000; denominator not clearly established in inspected text',
      'local_native_GBD_under28_rate':float(n['val']),'local_native_lower':float(n['lower']),'local_native_upper':float(n['upper']),
      'interpretation':'Same-source numeric concordance at published precision, NOT independent validation; not comparable numerically with per1000 live-birth indicator.',
      'source_url':'https://www.frontiersin.org/journals/medicine/articles/10.3389/fmed.2025.1536948/full'})
for year,value in [(1990,4.77),(2021,3.76)]:
    rows.append({'paper':'Jiang et al. 2025','year':year,'outcome':'Age-standardized mortality rate',
      'published_point':value,'published_lower':'','published_upper':'',
      'published_unit':'Per 100000 population, age-standardized',
      'local_native_GBD_under28_rate':'','local_native_lower':'','local_native_upper':'',
      'interpretation':'Different estimand. The inspected future projections concerned age-standardized incidence, not matching global neonatal mortality. Not a numeric validation of the primary indicator.',
      'source_url':'https://link.springer.com/article/10.1186/s12887-025-06044-2'})
write(SUP/'Table_S10c_published_study_comparison.csv',rows)

access=[
 {'check':'Matching official GBD forecast series','status':'Access-blocked; no matching series retrieved',
  'source_url':'https://vizhub.healthdata.org/gbd-foresight/',
  'needed':'Global, Both, neonatal sepsis and other neonatal infections, <28 days, 2022-2030, consistent metric/denominator',
  'not_permitted_claim':'Do not claim official forecasts agree or disagree without a retrieved matching series.'},
 {'check':'VR/VA country-year coverage specific to this cause and age','status':'Access-blocked; relevant metadata export unavailable',
  'source_url':'https://ghdx.healthdata.org/gbd-2021/sources',
  'needed':'Cause/age-relevant VR/VA inputs, national/subnational scope, coverage years and completeness; deduplicate country-years',
  'not_permitted_claim':'Do not infer VR coverage from estimate availability or citation counts.'}]
write(SUP/'Table_S10d_external_access_status.csv',access)
summary={'matched_countries':sum(bool(r['matching_source_available']) for r in comparison),
 'missing_countries':[r['location_name'] for r in comparison if not r['matching_source_available']],
 'country_specific_point_exceeds_all_cause':[r['location_name'] for r in comparison if r['specific_cause_point_exceeds_all_cause'] is True],
 'global_specific_rate':float(g2021['rate']),'global_UNICEF_all_cause_rate':float(world['OBS_VALUE']),
 'same_source_Mu_rate_and_interval_concordance':'PASS at published precision',
 'incomplete_checks':['Matching official forecast series','Cause-age-specific VR/VA country-year quantification']}
annual_source=mapped(SUP/'UNICEF_1990_2021_neonatal_mortality_source.csv')
if annual_source.exists():
    annual_url=unicef_url.replace('startPeriod=2021','startPeriod=1990')
    annual=[r for r in read(annual_source) if r['SEX']=='_T' and r['INDICATOR']=='CME_MRM0' and r['UNIT_MEASURE']=='D_PER_1000_B' and 1990<=int(r['TIME_PERIOD'])<=2021]
    annual_by={(r['REF_AREA'],r['TIME_PERIOD']):r for r in annual}
    assert len(annual_by)==len(annual)
    historical=[]
    for r in read(ASSETS/'Figure1/Figure1_analysis_country_rate_intervals.csv'):
        iso=geography[r['location_id']]['iso3']; other=annual_by.get((iso,r['year']))
        historical.append({'location_id':r['location_id'],'location_name':r['location_name'],'iso3':iso,'year':r['year'],
          'gbd_specific_cause_per1000':float(r['rate']),'UNICEF_all_cause_per1000':float(other['OBS_VALUE']) if other else '',
          'matching_source_available':bool(other),'specific_cause_point_exceeds_all_cause':float(r['rate'])>float(other['OBS_VALUE']) if other else '',
          'interpretation':'Cross-source point-magnitude check only; different cause definition and estimation framework',
          'source_url':annual_url,'retrieval_date':'2026-11-01'})
    write(SUP/'Table_S10e_UNICEF_country_year_plausibility.csv',historical)
    global_history=[]
    for r in g:
        if r['age_name']!='<28 days':continue
        other=annual_by[('WORLD',r['year'])]
        global_history.append({'year':r['year'],'gbd_specific_cause_per1000':float(r['rate']),
          'UNICEF_all_cause_per1000':float(other['OBS_VALUE']),'UNICEF_source_lower':float(other['LOWER_BOUND']),
          'UNICEF_source_upper':float(other['UPPER_BOUND']),'UNICEF_interval_level':'Not specified in downloaded CSV',
          'source_url':annual_url,'interpretation':'Current database estimates for historical years; all-cause context, not matching cause-specific validation'})
    write(SUP/'Table_S10f_UNICEF_global_historical_context.csv',global_history)
    summary['matched_country_years_1990_2021']=sum(bool(r['matching_source_available']) for r in historical)
    summary['country_year_specific_point_exceeds_all_cause']=[{'country':r['location_name'],'year':r['year']} for r in historical if r['specific_cause_point_exceeds_all_cause'] is True]
(REV/'scripts/external_comparison_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))
