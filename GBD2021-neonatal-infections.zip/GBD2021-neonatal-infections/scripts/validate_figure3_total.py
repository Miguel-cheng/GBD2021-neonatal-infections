import csv
import hashlib
import json
import math
from pathlib import Path
from project_layout import figure_assets_root
from PIL import Image, ImageChops

REV = Path(__file__).resolve().parents[1]
BASE = figure_assets_root(REV)/'Figure3'
def read(name):
    with (BASE/f'Figure3_analysis_{name}.csv').open(encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))
def q(values,p):
    values=sorted(values)
    x=(len(values)-1)*p
    i=int(x)
    return values[i]+(values[min(i+1,len(values)-1)]-values[i])*(x-i)

v=read('total_rolling_origin_predictions')
assert len(v)==8*9*6
assert all(int(r['training_last_year'])==int(r['origin'])<int(r['year']) for r in v)
scores=read('total_validation_scores')
for r in scores:
    errors=[float(d['estimate'])-float(d['actual']) for d in v if d['method']==r['method']]
    assert len(errors)==72
    assert math.isclose(float(r['MAE']),sum(abs(x) for x in errors)/72,rel_tol=1e-12)
    assert math.isclose(float(r['RMSE']),math.sqrt(sum(x*x for x in errors)/72),rel_tol=1e-12)
draws=read('approximate_simulation_draws_NOT_IHME_draws')
assert len(draws)==2000
forecast=read('total_forecast_with_approximate_intervals')
assert len(forecast)==9
for r in forecast:
    values=[float(d[f"rate_{r['year']}"]) for d in draws]
    assert all(math.isfinite(x) and x>0 for x in values)
    assert math.isclose(float(r['lower_approx']),q(values,.025),rel_tol=1e-12)
    assert math.isclose(float(r['upper_approx']),q(values,.975),rel_tol=1e-12)
    assert float(r['lower_approx'])<float(r['point_forecast'])<float(r['upper_approx'])
endpoint=read('2030_endpoint')[0]
changes=[(float(d['rate_2030'])/float(d['baseline_rate_2021'])-1)*100 for d in draws]
assert math.isclose(float(endpoint['change_lower_approx']),q(changes,.025),rel_tol=1e-12)
assert math.isclose(float(endpoint['change_upper_approx']),q(changes,.975),rel_tol=1e-12)
composition=read('historical_age_composition')
for year in range(1990,2022):
    rows=[r for r in composition if int(r['year'])==year]
    assert len(rows)==2 and math.isclose(sum(float(r['share']) for r in rows),1,abs_tol=1e-10)
plots=[]
for p in sorted(BASE.glob('Figure3?.tif')):
    im=Image.open(p)
    assert tuple(round(x) for x in im.info['dpi'])==(600,600)
    assert im.info['compression']=='tiff_lzw'
    rgb=im.convert('RGB')
    box=ImageChops.difference(rgb,Image.new('RGB',im.size,'white')).getbbox()
    assert box and box[0]>0 and box[1]>0 and box[2]<im.width and box[3]<im.height
    plots.append({'file':p.name,'size':im.size,'ink_bounds':box})
assert len(plots)==3
result={'checks':'PASS','rolling_comparisons':len(v),'simulations':len(draws),
  'checks_include':['no outer-origin future leakage','independent MAE/RMSE','simulation percentiles','change interval','age shares','600 dpi LZW TIFF and non-clipped ink bounds'],
  'plots':plots,'sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in BASE.glob('Figure3_raw_*.csv')},
  'limitations':'Numerical consistency verified; assumed input correlations are not empirically identified. These are not IHME joint draws, and this check does not establish clinical validity or guaranteed coverage.'}
(REV/'scripts/Figure3_total_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
