supplementary_path <- function(revision_dir,name) {
  mapping <- jsonlite::fromJSON(file.path(revision_dir,'scripts','supplementary_paths.json'))
  relative <- mapping[[name]]
  if(is.null(relative)) stop('Unmapped supplementary file: ',name)
  file.path(revision_dir,relative)
}
