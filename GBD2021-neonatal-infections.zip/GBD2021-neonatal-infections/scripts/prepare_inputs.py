"""Stage user-obtained inputs; input datasets are not distributed here."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args()
    records=json.loads((ROOT/'metadata/input_manifest.json').read_text())
    missing=[r['filename'] for r in records if not (ROOT/'inputs'/r['filename']).is_file()]
    if missing:
        raise SystemExit('Obtain the documented source files and place them in inputs/:\n'+'\n'.join(missing))
    for record in records:
        p=ROOT/'inputs'/record['filename']
        if hashlib.sha256(p.read_bytes()).hexdigest()!=record['sha256']:
            print('WARNING: source differs from retained export: '+record['filename']+'; exact published numerical agreement is not assured.')
    if args.check_only:
        print('PASS: all nine documented inputs are present.');return
    standard={'neonatal_deaths.csv':'neonatal_deaths.csv','global_mortality.csv':'global_original.csv',
      'country_reference_rates.csv':'country_reference_rates.csv','live_births.csv':'live_births.csv','sdi.csv':'sdi.csv'}
    for n in (1,2,4,5,6):
        for source,suffix in standard.items():
            shutil.copy2(ROOT/'inputs'/source,ROOT/f'assets/Figure{n}/Figure{n}_raw_{suffix}')
    for source,suffix in [('global_mortality.csv','global_original.csv'),('live_births.csv','live_births.csv')]:
        shutil.copy2(ROOT/'inputs'/source,ROOT/'assets/Figure3'/('Figure3_raw_'+suffix))
    for record in records:
        name=record['filename']
        if name.endswith('.XLSX'):
            shutil.copy2(ROOT/'inputs'/name,ROOT/'assets/Figure4'/name)
        elif name.startswith('UNICEF_'):
            target=ROOT/'scripts/Supplementary_internal_records'/name
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(ROOT/'inputs'/name,target)
    mapping=json.loads((ROOT/'scripts/supplementary_paths.json').read_text())
    for relative in mapping.values():(ROOT/relative).parent.mkdir(parents=True,exist_ok=True)
    print('PASS: input staging complete; original inputs unchanged.')

if __name__=='__main__':main()
