"""Export the final one-table-per-file values from the original table definitions."""
import csv
import json
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

ROOT=Path(__file__).resolve().parents[1]
payload=json.loads((ROOT/'scripts/table_payload/payload.json').read_text())
for book in payload['books']:
    target=Path(book['path'])
    with target.with_suffix('.csv').open('w',newline='',encoding='utf-8-sig') as f:
        writer=csv.writer(f);writer.writerow(book['headers']);writer.writerows(book['rows'])
    target.with_suffix('.notes.txt').write_text(book['title']+'\n\n'+'\n\n'.join(book['notes']),encoding='utf-8')
    wb=Workbook();ws=wb.active;ws.title='Table S'+str(book['number'])
    ws.append(['Table S'+str(book['number'])+'. '+book['title']]);ws.append([]);ws.append([])
    ws.append(book['headers'])
    for row in book['rows']:ws.append(row)
    for row in ws.iter_rows():
        for cell in row:cell.alignment=Alignment(vertical='top',wrap_text=True)
    for cell in ws[4]:cell.font=Font(bold=True)
    for i,width in enumerate(book['widths'],1):ws.column_dimensions[ws.cell(4,i).column_letter].width=width
    if book['number']==1:
        for row in ws.iter_rows(min_row=5):
            row[3].number_format='#,##0';row[4].number_format='#,##0'
    if book['number']==3:
        for row in ws.iter_rows(min_row=5):
            row[3].number_format='0.0';row[4].number_format='0.000'
    ws.append([])
    for note in book['notes']:ws.append([note])
    ws.freeze_panes='A5';wb.save(target)
    print('Exported',target.relative_to(ROOT))
