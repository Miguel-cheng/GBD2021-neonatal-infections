render_interval_figure <- function(revision_dir,figure) {
  suppressPackageStartupMessages({library(data.table);library(ggplot2)})
  source(file.path(revision_dir,'scripts','project_layout.R'),local=TRUE)
  base <- file.path(figure_assets_root(revision_dir),paste0('Figure',figure))
  source(file.path(revision_dir,'scripts','supplementary_path.R'),local=TRUE)
  source(file.path(revision_dir,'scripts','figure_font_style.R'),local=TRUE)
  read <- function(n) fread(file.path(base,n))
  prefix <- paste0('Figure',figure)
  save <- function(p,name,w=11,h=7,supplement=FALSE) {
    p <- publication_font(p,w,h)
    p <- p+labs(caption=NULL)
    target <- if(supplement) supplementary_path(revision_dir,paste0(name,'.tif')) else file.path(base,paste0(name,'.tif'))
    ggsave(target,p,width=w,height=h,
      dpi=600,device=ragg::agg_tiff,compression='lzw',bg='white')
  }
  theme_set(theme_classic(base_size=18,base_family='Arial')+
    theme(legend.position='top',plot.margin=margin(24,32,24,28)))
  unit <- 'Deaths per 1,000 live births'
  cp <- c(Africa='#FCC8B1',Americas='#277D93',Asia='#E9CE77',Europe='#789262',Oceania='#F39402')
  sp <- c('Low SDI'='#00868F','Low-middle SDI'='#9C6D57','Middle SDI'='#00A68C','High-middle SDI'='#7A9EB1','High SDI'='#F2E8C9')
  if(figure==1) {
    x <- read('Figure1_analysis_continent_rate_intervals.csv')[year==2021]
    p <- ggplot(x,aes(reorder(group,-rate),rate))+geom_col(fill='#76C1C4',width=.65)+
      geom_errorbar(aes(ymin=lower_approx,ymax=upper_approx),width=.18,linewidth=.6)+
      geom_text(aes(y=upper_approx,label=sprintf('%.2f',rate)),vjust=-.5)+
      scale_y_continuous(expand=expansion(mult=c(0,.12)))+labs(x=NULL,y=unit,title='2021 continent mortality')
    save(p,'Figure1b')
  }
  if(figure==2) {
    g <- read('Figure2_analysis_global_rate_intervals.csv')
    c <- read('Figure2_analysis_continent_rate_intervals.csv')
    x <- read('Figure2_analysis_country_rate_intervals.csv')[location_name %in% c('China','Ethiopia','India','Nigeria')]
    p <- ggplot(g,aes(year,rate))+geom_ribbon(aes(ymin=lower_approx,ymax=upper_approx),fill='#023C71',alpha=.15)+
      geom_line(color='#023C71',linewidth=.9)+labs(x='Year',y=unit,title='Global mortality, 1990-2021')
    save(p,'Figure2a')
    p <- ggplot(c,aes(year,rate,color=group,fill=group))+
      geom_ribbon(aes(ymin=lower_approx,ymax=upper_approx),alpha=.12,colour=NA)+geom_line(linewidth=.85)+
      scale_color_manual(values=cp)+scale_fill_manual(values=cp)+guides(fill='none')+
      labs(x='Year',y=unit,color=NULL,title='Continent mortality')
    save(p,'Figure2b')
    pal <- c(China='#F8766D',Ethiopia='#7CAE00',India='#00BFC4',Nigeria='#C77CFF')
    p <- ggplot(x,aes(year,rate,color=location_name,fill=location_name))+
      geom_ribbon(aes(ymin=lower_approx,ymax=upper_approx),alpha=.12,colour=NA)+geom_line(linewidth=.85)+
      scale_color_manual(values=pal)+scale_fill_manual(values=pal)+guides(fill='none')+
      labs(x='Year',y=unit,color=NULL,title='Selected countries')
    save(p,'Figure2c')
  }
  if(figure==4) {
    x <- read('Figure4_analysis_SDI_rate_intervals.csv')
    x[,group:=factor(group,levels=names(sp))]
    gap <- read('Figure4_analysis_gap_intervals.csv')
    fwrite(gap,file.path(dirname(supplementary_path(revision_dir,'Figure_S1_SDI_absolute_gap.tif')),
      'Figure_S1_SDI_absolute_gap_analysis_data.csv'),bom=TRUE)
    p <- ggplot(x,aes(year,rate,color=group,fill=group))+
      geom_ribbon(aes(ymin=lower_approx,ymax=upper_approx),alpha=.12,colour=NA)+geom_line(linewidth=.85)+
      scale_color_manual(values=sp)+scale_fill_manual(values=sp)+guides(fill='none')+
      labs(x='Year',y=unit,color=NULL,title='Country groups defined by 2021 SDI')
    save(p,'Figure4a',12,7)
    p <- ggplot(x[year==2021],aes(group,rate,fill=group))+geom_col()+
      geom_errorbar(aes(ymin=lower_approx,ymax=upper_approx),width=.18,linewidth=.6)+
      scale_fill_manual(values=sp)+guides(fill='none')+
      labs(x=NULL,y=unit,title='Mortality by country-level SDI group, 2021')
    save(p,'Figure4b',12,7)
    p <- ggplot(gap,aes(year,high_low_point_estimate))+
      geom_ribbon(aes(ymin=high_low_lower_approx,ymax=high_low_upper_approx),fill='#EE7803',alpha=.15)+
      geom_line(color='#EE7803',linewidth=.85)+labs(x='Year',y='High / low SDI rate ratio',title='High-to-low SDI mortality ratio')
    save(p,'Figure4c')
    p <- ggplot(gap,aes(year,absolute_gap))+
      geom_ribbon(aes(ymin=absolute_lower_approx,ymax=absolute_upper_approx),fill='#EE7803',alpha=.15)+
      geom_line(color='#EE7803',linewidth=.85)+labs(x='Year',y=paste('Absolute gap:',unit),title='Absolute gap between low- and high-SDI country groups')
    save(p,'Figure_S1_SDI_absolute_gap',12,7,TRUE)
  }
  if(figure==5) {
    rates <- read('Figure5_analysis_country_rate_intervals.csv')[year==2021]
    changes <- read('Figure5_analysis_country_change_intervals.csv')
    chosen <- read('Figure5_analysis_slowest10_within_top30_2021.csv')
    a <- rates[order(-rate)][1:10]
    b <- merge(chosen[,.(location_id,location_name,reduction_percent)],
      changes[,.(location_id,reduction_lower_approx,reduction_upper_approx)],by='location_id')
    p <- ggplot(a,aes(rate,reorder(location_name,rate)))+geom_col(fill='#f8c387',width=.65)+
      geom_errorbar(aes(xmin=lower_approx,xmax=upper_approx),orientation='y',width=.25,color='#024943',linewidth=.6)+
      labs(x=unit,y=NULL,title='Ten highest country point estimates, 2021')
    save(p,'Figure5a',12,8)
    p <- ggplot(b,aes(reduction_percent,reorder(location_name,-reduction_percent)))+geom_col(fill='#f8c387',width=.65)+
      geom_errorbar(aes(xmin=reduction_lower_approx,xmax=reduction_upper_approx),orientation='y',width=.25,color='#024943',linewidth=.6)+
      geom_vline(xintercept=0,linetype=3,color='grey40')+
      labs(x='Reduction from 1990 to 2021 (%)',y=NULL,title='Smallest reductions among the 30 highest in 2021')
    save(p,'Figure5b',12,8)
  }
  if(figure==6) {
    x <- read('Figure6_analysis_curve_uncertainty.csv')
    anchors <- data.table(year=rep(c(1990,2021),each=2),cumulative_birth_share=rep(c(0,1),2),
      point_estimate=rep(c(0,1),2),lower_approx=rep(c(0,1),2),upper_approx=rep(c(0,1),2))
    x <- rbindlist(list(x,anchors),fill=TRUE);setorder(x,year,cumulative_birth_share)
    pal <- c('1990'='#345F65','2021'='#AE4F49')
    p <- ggplot(x,aes(cumulative_birth_share,point_estimate,color=factor(year),fill=factor(year)))+
      geom_ribbon(aes(ymin=lower_approx,ymax=upper_approx),alpha=.14,colour=NA)+geom_line(linewidth=.85)+
      geom_abline(slope=1,intercept=0,color='#656A7D',linetype=2)+
      scale_color_manual(values=pal)+scale_fill_manual(values=pal)+guides(fill='none')+
      labs(x='Cumulative live-birth share (ranked by SDI)',y='Cumulative death share',color=NULL,title='Concentration curves')
    save(p,'Figure6a',11,8)
    x <- read('Figure6_analysis_concentration_index_intervals.csv')
    p <- ggplot(x,aes(year,point_estimate))+
      geom_ribbon(aes(ymin=lower_approx,ymax=upper_approx),fill='#14375F',alpha=.15)+
      geom_line(color='#14375F',linewidth=.85)+labs(x='Year',y='Concentration index',title='Birth-weighted concentration index')
    save(p,'Figure6b')
    x <- read('Figure6_analysis_frontier_input_uncertainty.csv');setorder(x,sdi2021,location_id)
    band <- rbindlist(lapply(1:nrow(x),function(i) {
      z <- copy(x[i]);z[,sdi2021:=x$sdi2021[min(i+1,nrow(x))]]
      rbind(x[i],z)
    }))
    p <- ggplot(x,aes(sdi2021,rate_point))+
      geom_ribbon(data=band,aes(ymin=frontier_lower_approx,ymax=frontier_upper_approx),fill='#2E8B57',alpha=.13)+
      geom_point(color='#7BCCC4',size=1.6)+geom_step(aes(y=frontier_point),color='#2E8B57',linewidth=.8,direction='hv')+
      labs(x='SDI',y=unit,title='Empirical attainable envelope, 2021')
    save(p,'Figure6c',11,8)
    z <- fread(supplementary_path(revision_dir,'Table_S6_concentration_curve_comparison.csv'))
    fwrite(z,file.path(dirname(supplementary_path(revision_dir,'Figure_S2_concentration_curve_difference.tif')),
      'Figure_S2_concentration_curve_difference_analysis_data.csv'),bom=TRUE)
    p <- ggplot(z,aes(cumulative_birth_share,100*difference_2021_minus1990))+
      geom_ribbon(aes(ymin=100*lower_simultaneous_approx,ymax=100*upper_simultaneous_approx),fill='#AE4F49',alpha=.15)+
      geom_line(color='#AE4F49',linewidth=.85)+geom_hline(yintercept=0,color='#656A7D',linetype=2)+
      labs(x='Cumulative live-birth share (ranked by SDI)',y='Death-share difference (percentage points)',title='Difference between the 2021 and 1990 concentration curves')
    save(p,'Figure_S2_concentration_curve_difference',12,8,TRUE)
  }
  writeLines(c(paste('Figure',figure,'interval graphics updated.'),
    'Bands and error bars are approximate 95% simulation intervals under explicit marginal and dependence assumptions, not official IHME joint-draw UIs.',
    'Central country model: lognormal marginal distributions; annual AR(1) rho=0.9; common-country correlation=0.5; death-birth error correlation=0.',
    'Global annual intervals reuse Figure3 simulations based on official global inputs, not country sums.',
    'Pointwise bands are not simultaneous confidence bands unless explicitly labelled in Supplementary.',
    'LOO sensitivity and simulation fractions must not be called confidence intervals or p-values.'),
    file.path(revision_dir,'scripts',paste0('Figure',figure,'_interval_legend_notes.txt')))
  writeLines(c('COMPLETED: point estimates and approximate simulation intervals rendered.',
    'Intervals depend on explicit assumptions and are not official IHME joint-draw UIs.'),
    file.path(revision_dir,'scripts',prefix,'STATUS.txt'))
  message('Completed Figure ',figure,': interval graphics saved to the current figure container.')
}
if(sys.nframe()==0L) {
  a <- commandArgs(FALSE);p <- sub('^--file=','',a[grepl('^--file=',a)][1])
  p <- gsub('~+~',' ',p,fixed=TRUE)
  root <- dirname(dirname(normalizePath(p)))
  for(fig in c(1,2,4,5,6)) render_interval_figure(root,fig)
}
