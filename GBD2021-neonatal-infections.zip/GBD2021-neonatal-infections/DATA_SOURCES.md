# Input acquisition specification

No numerical input dataset is included. Acquire the source files under the provider's applicable terms and save them in `inputs/` with the filenames below. The manifest records the schemas and fingerprints of the retained extracts, not a claim that a new provider export will be byte-identical. A current UNICEF export may revise historical values; retain its actual retrieval date and do not label it as the 2026-11-01 snapshot.

## IHME GBD 2021

Results Tool: https://gbd2021.healthdata.org/
Data catalog: https://ghdx.healthdata.org/gbd-2021
SDI release: https://ghdx.healthdata.org/record/ihme-data/gbd-2021-socio-demographic-index-sdi-1950-2021

- `neonatal_deaths.csv`: retained export IHME-GBD_2021_DATA-65d5cdc5-1; Deaths / Number; neonatal sepsis and other neonatal infections; Both; 204 countries and territories; ages <28 days, 0-6 days and 7-27 days. Retain 1990-2021. Retrieved November 1, 2026.
- `global_mortality.csv`: retained global export IHME-GBD_2021_DATA-a3d7e3cd-1; same cause and sex, the three neonatal age groups; Number used for analysis and Rate records retained only for native-rate comparison. Original retained download acquired September 26, 2025.
- `country_reference_rates.csv`: retained export IHME-GBD_2021_DATA-3cba4a81-1, identifying the 204 national/territorial location IDs. It is not the primary outcome denominator. No retrieval date is asserted here for this separate reference export.
- `live_births.csv`: release IHME_GBD_2021_FERTILITY_1950_2100_LB_Y2024M03D15.CSV; Live Births / Number / Reference; matching national and Global locations. Only 1990-2021 is analyzed. Retained file acquired April 5, 2026.
- `sdi.csv`: IHME_GBD_SDI_2021_SDI_1950_2021_Y2024M05D16.csv; Both / All Ages; annual national SDI. Retained file acquired April 5, 2026.
- `IHME_GBD_SDI_2021_SDI_QUINTILES_Y2024M05D16.XLSX`: published national SDI classification workbook.
- `IHME_GBD_SDI_2021_REF_QUINTILES_Y2024M05D16.XLSX`: reference group boundaries workbook. Both workbooks were retrieved November 1, 2026. Fixed national grouping uses 182 direct labels and 22 national threshold assignments.

Historical files may have more years, locations or metrics than the retained analytical subset. Inspect `metadata/input_manifest.json` for the exact expected columns. Ensure that all sources belong to GBD 2021 rather than mixing estimation rounds.

## UNICEF / UN IGME

API: https://sdmx.data.unicef.org/ws/public/sdmxapi/rest/data/
Dataflow: UNICEF,GLOBAL_DATAFLOW,1.0. Indicator: CME_MRM0. Sex: _T. Unit: D_PER_1000_B. Format: SDMX-CSV with all dimensions retained. Include WORLD and countries. The retained responses were retrieved November 1, 2026.

- `UNICEF_2021_neonatal_mortality_source.csv`: 2021 response.
- `UNICEF_1990_2021_neonatal_mortality_source.csv`: 1990-2021 response.

Example request: https://sdmx.data.unicef.org/ws/public/sdmxapi/rest/data/UNICEF,GLOBAL_DATAFLOW,1.0/.CME_MRM0..?startPeriod=1990&endPeriod=2021&format=sdmx-csv&dimensionAtObservation=AllDimensions

The comparison is all-cause context, not matched cause-specific validation. Missing country matches are not imputed. Interval confidence levels are not invented when unspecified in the response.

## Source citations

GBD 2021 Causes of Death Collaborators. Global burden of 288 causes of death and life expectancy decomposition in 204 countries and territories and 811 subnational locations, 1990-2021. Lancet. 2024;403:2100-2132. https://doi.org/10.1016/S0140-6736(24)00367-2

GBD 2021 Demographics Collaborators. Global age-sex-specific mortality, life expectancy, and population estimates, 1950-2021. Lancet. 2024;403:1989-2056. https://doi.org/10.1016/S0140-6736(24)00476-8

Mu et al. Analysis of the global burden and key risk factors of neonatal sepsis and other neonatal infections in 204 countries and territories, 1990-2021. Front Med. 2025;12:1536948. https://doi.org/10.3389/fmed.2025.1536948

Jiang et al. Global, regional, and national incidence and mortality of neonatal sepsis and other neonatal infections, 1990-2021 and predictions to 2050. BMC Pediatr. 2025;25:711. https://doi.org/10.1186/s12887-025-06044-2

This package does not redistribute third-party datasets or represent the above source references as licenses. Data redistribution permissions were not conclusively verified during package preparation. Requests for unavailable retained extracts should be resolved with the provider and study authors under the applicable terms.
